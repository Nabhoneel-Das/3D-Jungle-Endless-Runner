/**
 * 3D Jungle Endless Runner - Three.js Procedural Game Engine
 */

import * as THREE from 'three';
import { GamePhase, CharacterSkin, Lane, PowerUpType, ObstacleType, PlayerStats, ObstacleInstance, CoinInstance, PowerUpInstance } from './types';
import { audio } from './audio';

export class GameEngine {
  // Elements
  private container: HTMLDivElement;
  private canvas: HTMLCanvasElement;
  
  // React updates
  private onScoreUpdate: (score: number) => void;
  private onCoinsUpdate: (coins: number) => void;
  private onMultiplierUpdate: (mult: number) => void;
  private onGamePhaseChange: (phase: GamePhase) => void;
  private onPowerUpActive: (type: PowerUpType | null, progress: number) => void;
  private onStatsSync: (stats: PlayerStats) => void;
  private onLivesUpdate: (lives: number) => void;
  private onRadarSync?: (data: {
    obstacles: { lane: Lane; distance: number; type: ObstacleType }[];
    powerups: { lane: Lane; distance: number; type: PowerUpType }[];
    coins: { lane: Lane; distance: number }[];
  }) => void;

  // Three.js Core
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private renderer!: THREE.WebGLRenderer;
  private clock!: THREE.Clock;
  private animationFrameId: number | null = null;

  // Lights & Fog
  private sunLight!: THREE.DirectionalLight;
  private ambientLight!: THREE.AmbientLight;
  private torchLights: THREE.PointLight[] = [];

  // Game Settings & Speeds
  private runSpeed = 22.0;
  private readonly maxRunSpeed = 58.0;
  private speedMultiplier = 1.0;
  private acceleration = 0.22; // meters/sec^2
  private laneWidth = 3.2; // Width of a single lane
  private lastTime = 0;

  // Scores
  private stats: PlayerStats = {
    score: 0,
    coins: 0,
    multiplier: 1,
    highScore: 0,
    totalCoins: 0
  };

  // State
  private gamePhase: GamePhase = 'START';
  private runDistance = 0; // z offset
  private coinCount = 0;

  // Player Entity Structure
  private playerGroup!: THREE.Group;
  private playerBody!: THREE.Mesh;
  private playerHead!: THREE.Mesh;
  private playerLeftLeg!: THREE.Group;
  private playerRightLeg!: THREE.Group;
  private playerLeftArm!: THREE.Group;
  private playerRightArm!: THREE.Group;
  private playerFedoraHat!: THREE.Mesh;
  private shirtMaterial!: THREE.MeshStandardMaterial;
  private pantsMaterial!: THREE.MeshStandardMaterial;
  private hatMaterial!: THREE.MeshStandardMaterial;

  // Player state variables
  private playerLane: Lane = 0;
  private targetLaneX = 0;
  private jumpTimer = 0;
  private readonly jumpDuration = 0.65;
  private readonly jumpHeight = 3.0;
  private isJumping = false;

  private slideTimer = 0;
  private readonly slideDuration = 0.75;
  private isSliding = false;

  private isCrashed = false;
  private crashTimer = 0;
  private radarFrameCounter = 0;

  // Lives with hit invulnerability window
  private lives = 3;
  private isInvulnerable = false;
  private invulnerableTimer = 0;
  private readonly invulnerableDurationMax = 2.0;

  // Power Up state variables
  private activePowerUp: PowerUpType | null = null;
  private powerUpTimer = 0;
  private powerUpDurationMax = 8000; // 8 seconds default
  private isShieldActive = false;
  private isMagnetActive = false;
  private isBoostActive = false;
  private shieldBubbleMesh: THREE.Mesh | null = null;

  // Camera settings
  private targetCamX = 0;
  private camBaseOffset = new THREE.Vector3(0, 4.2, 8.5);
  private currentCamOffsetY = 4.2;
  private currentCamOffsetZ = 8.5;
  private cameraShakeIntensity = 0;

  // Preallocated performance math helpers
  private reusableVector3 = new THREE.Vector3();
  private reusableLookTarget = new THREE.Vector3();

  // Procedural Segmentation Tracks
  private segments: THREE.Group[] = [];
  private readonly segmentLength = 40.0;
  private readonly segmentsAhead = 8;
  private lastSegmentZ = 0;
  private segmentIndexCounter = 0;

  // Game Instances
  private activeObstacles: ObstacleInstance[] = [];
  private obstacleMeshes: THREE.Object3D[] = [];
  
  private activeCoins: CoinInstance[] = [];
  private coinsMeshes: THREE.Object3D[] = [];

  private activePowerUps: PowerUpInstance[] = [];
  private powerUpMeshes: THREE.Object3D[] = [];

  // Particle systems
  private runningParticles!: THREE.Points;
  private sparksParticles!: THREE.Points;
  private windTunnelParticles!: THREE.Points;
  private collectionFlashParticles!: THREE.Points;
  private runningParticleVelocity: number[] = [];
  private sparkVelocity: number[] = [];
  private windVelocity: number[] = [];

  // Reusable materials & geometries for absolute optimization
  private materialsList: { [key: string]: THREE.Material } = {};
  private geometriesList: { [key: string]: THREE.BufferGeometry } = {};

  constructor(
    container: HTMLDivElement,
    canvas: HTMLCanvasElement,
    callbacks: {
      onScoreUpdate: (score: number) => void;
      onCoinsUpdate: (coins: number) => void;
      onMultiplierUpdate: (mult: number) => void;
      onGamePhaseChange: (phase: GamePhase) => void;
      onPowerUpActive: (type: PowerUpType | null, progress: number) => void;
      onStatsSync: (stats: PlayerStats) => void;
      onLivesUpdate: (lives: number) => void;
      onRadarSync?: (data: {
        obstacles: { lane: Lane; distance: number; type: ObstacleType }[];
        powerups: { lane: Lane; distance: number; type: PowerUpType }[];
        coins: { lane: Lane; distance: number }[];
      }) => void;
    }
  ) {
    this.container = container;
    this.canvas = canvas;
    this.onScoreUpdate = callbacks.onScoreUpdate;
    this.onCoinsUpdate = callbacks.onCoinsUpdate;
    this.onMultiplierUpdate = callbacks.onMultiplierUpdate;
    this.onGamePhaseChange = callbacks.onGamePhaseChange;
    this.onPowerUpActive = callbacks.onPowerUpActive;
    this.onStatsSync = callbacks.onStatsSync;
    this.onLivesUpdate = callbacks.onLivesUpdate;
    this.onRadarSync = callbacks.onRadarSync;

    // Load Highscore from localStorage
    const savedHighScore = localStorage.getItem('temple_runner_high_score');
    const savedTotalCoins = localStorage.getItem('temple_runner_total_coins');
    this.stats.highScore = savedHighScore ? parseInt(savedHighScore, 10) : 0;
    this.stats.totalCoins = savedTotalCoins ? parseInt(savedTotalCoins, 10) : 0;

    this.initThree();
    this.createMaterialsAndGeometries();
    this.setupJungleScene();
    this.createPlayer();
    this.createParticleSystems();
    this.generateInitialSegments();
    
    // Bind Keyboard Listeners
    window.addEventListener('keydown', this.handleKeyDown);

    // Initial resize trigger
    this.handleWindowResize();
    window.addEventListener('resize', this.handleWindowResize);

    // Boot loop
    this.clock = new THREE.Clock();
    this.animate();
  }

  /**
   * Safe destructor to avoid memory leaks on React unmounts
   */
  public destroy() {
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('resize', this.handleWindowResize);
    
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
    
    // Dispose resources
    audio.stopMusic();

    Object.values(this.materialsList).forEach(mat => mat.dispose());
    Object.values(this.geometriesList).forEach(geo => geo.dispose());

    if (this.shirtMaterial) this.shirtMaterial.dispose();
    if (this.pantsMaterial) this.pantsMaterial.dispose();
    if (this.hatMaterial) this.hatMaterial.dispose();

    this.torchLights = [];
    this.obstacleMeshes = [];
    this.coinsMeshes = [];
    this.powerUpMeshes = [];

    this.renderer.dispose();
  }

  private initThree() {
    // 1. Create Scene
    this.scene = new THREE.Scene();

    // Beautiful, bright lush daylight sky atmosphere (Soft blue fog)
    this.scene.background = new THREE.Color(0xb5e2ff);
    this.scene.fog = new THREE.FogExp2(0xb5e2ff, 0.011); // Daytime soft visibility fog

    // 2. Camera Setup
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    this.camera = new THREE.PerspectiveCamera(62, width / height, 0.1, 800);
    this.camera.position.set(0, 4.5, 9);

    // 3. Renderer Setup with Shadows
    this.renderer = new THREE.WebGLRenderer({
      canvas: this.canvas,
      antialias: true,
      powerPreference: 'high-performance',
      alpha: false,
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.3)); // Optimized pixel ratio threshold for high screen density devices
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  }

  private handleWindowResize = () => {
    if (!this.container || !this.renderer) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();

    this.renderer.setSize(width, height);
  };

  /**
   * Shared mesh pools for high rendering efficiency
   */
  private createMaterialsAndGeometries() {
    // Geometries
    this.geometriesList['lane_road'] = new THREE.BoxGeometry(10.2, 1.2, this.segmentLength);
    this.geometriesList['border_wall'] = new THREE.BoxGeometry(1.5, 3.5, this.segmentLength);
    this.geometriesList['coin'] = new THREE.TorusGeometry(0.38, 0.09, 8, 24);
    this.geometriesList['tree_trunk'] = new THREE.CylinderGeometry(0.3, 0.5, 12, 6);
    this.geometriesList['tree_foliage'] = new THREE.ConeGeometry(2.2, 5.0, 5);
    this.geometriesList['rock'] = new THREE.DodecahedronGeometry(1.6);
    this.geometriesList['pillar'] = new THREE.BoxGeometry(1.4, 6.0, 1.4);
    this.geometriesList['arch_beam'] = new THREE.BoxGeometry(9.5, 1.4, 1.6);

    this.geometriesList['spikes'] = new THREE.ConeGeometry(0.12, 0.9, 4);
    this.geometriesList['barrier_high'] = new THREE.BoxGeometry(8.5, 1.3, 0.7);
    this.geometriesList['barrier_low'] = new THREE.BoxGeometry(6.6, 1.0, 0.7);
    this.geometriesList['shield_powerup'] = new THREE.OctahedronGeometry(0.65, 0);
    this.geometriesList['magnet_powerup'] = new THREE.TorusGeometry(0.4, 0.16, 6, 12, Math.PI); // Half torus horseshoe magnet
    this.geometriesList['boost_powerup'] = new THREE.IcosahedronGeometry(0.5, 0);

    // Materials
    // Mossy stone brick texture simulated with high-quality vertex coloring + roughness
    this.materialsList['road'] = new THREE.MeshStandardMaterial({
      color: 0x222a24,
      roughness: 0.91,
      metalness: 0.05,
    });
    this.materialsList['mossy_bricks'] = new THREE.MeshStandardMaterial({
      color: 0x142018,
      roughness: 0.95,
      metalness: 0.02,
    });
    this.materialsList['stone_pillar'] = new THREE.MeshStandardMaterial({
      color: 0x2e3530,
      roughness: 0.85,
    });
    this.materialsList['gold_coin'] = new THREE.MeshStandardMaterial({
      color: 0xffd700,
      roughness: 0.1,
      metalness: 0.95,
      emissive: 0xb38600,
      emissiveIntensity: 0.4
    });
    this.materialsList['tree_wood'] = new THREE.MeshStandardMaterial({
      color: 0x3d2314,
      roughness: 0.91
    });
    this.materialsList['leaves'] = new THREE.MeshStandardMaterial({
      color: 0x052e16,
      roughness: 0.95
    });
    this.materialsList['rock_grey'] = new THREE.MeshStandardMaterial({
      color: 0x333b37,
      roughness: 0.88,
    });

    // Obstacles
    this.materialsList['obstacle_hazard'] = new THREE.MeshStandardMaterial({
      color: 0x5a180d,
      roughness: 0.75,
      emissive: 0x1a0502
    });
    this.materialsList['spikes_metallic'] = new THREE.MeshStandardMaterial({
      color: 0x424945,
      roughness: 0.25,
      metalness: 0.8
    });

    // Power Ups
    this.materialsList['shield'] = new THREE.MeshStandardMaterial({
      color: 0x0ea5e9, // Bright Sky Blue
      emissive: 0x0284c7,
      emissiveIntensity: 1.0,
      transparent: true,
      opacity: 0.8,
    });
    this.materialsList['magnet'] = new THREE.MeshStandardMaterial({
      color: 0xef4444, // Red
      emissive: 0x991b1b,
      emissiveIntensity: 0.8,
      roughness: 0.2
    });
    this.materialsList['boost'] = new THREE.MeshStandardMaterial({
      color: 0x22c55e, // Emerald Green
      emissive: 0x15803d,
      emissiveIntensity: 0.8,
    });
  }

  private setupJungleScene() {
    // 1. Ambient Jungle Under-canopy glow (lush daytime greenery bounce)
    this.ambientLight = new THREE.AmbientLight(0x2d4f3b, 1.5);
    this.scene.add(this.ambientLight);

    // 2. High Cinematic Daylight Sun (bright warm light caster)
    this.sunLight = new THREE.DirectionalLight(0xfff8ed, 2.2);
    this.sunLight.position.set(12, 28, 8);
    this.sunLight.castShadow = true;
    
    // Shadow parameters optimized for smooth framerates on low-end devices
    this.sunLight.shadow.mapSize.width = 512;
    this.sunLight.shadow.mapSize.height = 512;
    this.sunLight.shadow.camera.near = 0.5;
    this.sunLight.shadow.camera.far = 85;
    
    const d = 26;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.sunLight.shadow.bias = -0.001;
    
    this.scene.add(this.sunLight);

    // Vast bottom backdrop plane so players won't look into empty void in gaps
    const pitGeo = new THREE.PlaneGeometry(350, 600);
    const pitMat = new THREE.MeshBasicMaterial({ color: 0x040806, transparent: true, opacity: 0.9 });
    const pitPlane = new THREE.Mesh(pitGeo, pitMat);
    pitPlane.rotation.x = -Math.PI / 2;
    pitPlane.position.y = -12.0;
    this.scene.add(pitPlane);
  }

  /**
   * Blocky Indiana Jones Explorer design constructed from fundamental geometry meshes
   */
  private createPlayer() {
    this.playerGroup = new THREE.Group();

    // Load active skin colors or default to TAN
    const savedSkin = (localStorage.getItem('temple_runner_skin') || 'TAN') as CharacterSkin;
    const skinConfig = this.getSkinColors(savedSkin);

    // Instantiate dynamic materials with selected colors
    this.shirtMaterial = new THREE.MeshStandardMaterial({ color: skinConfig.shirt, roughness: 0.8 });
    this.pantsMaterial = new THREE.MeshStandardMaterial({ color: skinConfig.pants, roughness: 0.9 });
    this.hatMaterial = new THREE.MeshStandardMaterial({ color: skinConfig.hat, roughness: 0.85 });

    // 1. Torso: Explorer's Shirt
    const torsoGeo = new THREE.BoxGeometry(0.88, 1.1, 0.46);
    this.playerBody = new THREE.Mesh(torsoGeo, this.shirtMaterial);
    this.playerBody.position.y = 1.15;
    this.playerBody.castShadow = true;
    this.playerBody.receiveShadow = true;
    this.playerGroup.add(this.playerBody);

    // Leather satchel belt across shoulder
    const beltGeo = new THREE.BoxGeometry(0.92, 0.12, 0.5);
    const leatherMat = new THREE.MeshStandardMaterial({ color: 0x542c12, roughness: 0.9 }); // Dark Brown
    const chestBelt = new THREE.Mesh(beltGeo, leatherMat);
    chestBelt.rotation.z = 0.35;
    chestBelt.position.set(0, 0, 0.01);
    this.playerBody.add(chestBelt);

    // 2. Head
    const headGeo = new THREE.BoxGeometry(0.55, 0.55, 0.5);
    const skinMat = new THREE.MeshStandardMaterial({ color: 0xffdbac, roughness: 0.7 }); // skin tone
    this.playerHead = new THREE.Mesh(headGeo, skinMat);
    this.playerHead.position.set(0, 0.82, 0);
    this.playerHead.castShadow = true;
    this.playerBody.add(this.playerHead);

    // Fedora Hat
    const hatBaseGeo = new THREE.BoxGeometry(1.0, 0.07, 0.95);
    const hatCrownGeo = new THREE.BoxGeometry(0.59, 0.28, 0.54);
    
    this.playerFedoraHat = new THREE.Mesh(hatCrownGeo, this.hatMaterial);
    this.playerFedoraHat.position.set(0, 0.32, 0);
    
    const brim = new THREE.Mesh(hatBaseGeo, this.hatMaterial);
    brim.position.set(0, -0.15, 0);
    this.playerFedoraHat.add(brim);
    
    this.playerFedoraHat.castShadow = true;
    this.playerHead.add(this.playerFedoraHat);

    // 3. Legs (Cargo pants)
    const legGeo = new THREE.BoxGeometry(0.3, 0.65, 0.35);

    // Left leg
    this.playerLeftLeg = new THREE.Group();
    const lLegMesh = new THREE.Mesh(legGeo, this.pantsMaterial);
    lLegMesh.position.y = -0.32;
    lLegMesh.castShadow = true;
    this.playerLeftLeg.add(lLegMesh);
    this.playerLeftLeg.position.set(-0.25, 0.55, 0);
    this.playerGroup.add(this.playerLeftLeg);

    // Right leg
    this.playerRightLeg = new THREE.Group();
    const rLegMesh = new THREE.Mesh(legGeo, this.pantsMaterial);
    rLegMesh.position.y = -0.32;
    rLegMesh.castShadow = true;
    this.playerRightLeg.add(rLegMesh);
    this.playerRightLeg.position.set(0.25, 0.55, 0);
    this.playerGroup.add(this.playerRightLeg);

    // Boots (Dark brick red/black)
    const bootGeo = new THREE.BoxGeometry(0.32, 0.16, 0.44);
    const bootMat = new THREE.MeshStandardMaterial({ color: 0x1f1712, roughness: 0.9 });
    const leftBoot = new THREE.Mesh(bootGeo, bootMat);
    leftBoot.position.set(0, -0.65, 0.05);
    this.playerLeftLeg.add(leftBoot);

    const rightBoot = new THREE.Mesh(bootGeo, bootMat);
    rightBoot.position.set(0, -0.65, 0.05);
    this.playerRightLeg.add(rightBoot);

    // 4. Arms
    const armGeo = new THREE.BoxGeometry(0.24, 0.75, 0.24);

    // Left arm
    this.playerLeftArm = new THREE.Group();
    const lArmMesh = new THREE.Mesh(armGeo, this.shirtMaterial);
    lArmMesh.position.y = -0.32;
    lArmMesh.castShadow = true;
    this.playerLeftArm.add(lArmMesh);
    this.playerLeftArm.position.set(-0.58, 0.5, 0);
    this.playerBody.add(this.playerLeftArm);

    // Right arm
    this.playerRightArm = new THREE.Group();
    const rArmMesh = new THREE.Mesh(armGeo, this.shirtMaterial);
    rArmMesh.position.y = -0.32;
    rArmMesh.castShadow = true;
    this.playerRightArm.add(rArmMesh);
    this.playerRightArm.position.set(0.58, 0.5, 0);
    this.playerBody.add(this.playerRightArm);

    // Hand sleeves
    const handGeo = new THREE.BoxGeometry(0.22, 0.15, 0.22);
    const leftHand = new THREE.Mesh(handGeo, skinMat);
    leftHand.position.set(0, -0.7, 0);
    this.playerLeftArm.add(leftHand);

    const rightHand = new THREE.Mesh(handGeo, skinMat);
    rightHand.position.set(0, -0.7, 0);
    this.playerRightArm.add(rightHand);

    // 5. Shield Bubble (Unloaded by default)
    const bubbleGeo = new THREE.SphereGeometry(1.65, 16, 16);
    this.shieldBubbleMesh = new THREE.Mesh(bubbleGeo, this.materialsList['shield']);
    this.shieldBubbleMesh.position.set(0, 0.7, 0);
    this.shieldBubbleMesh.visible = false;
    this.playerGroup.add(this.shieldBubbleMesh);

    // Add Player to Scene
    this.playerGroup.position.set(0, 0, 0);
    this.scene.add(this.playerGroup);
  }

  /**
   * Sets up running dust, flame sparks, wind boosts, and grab rings
   */
  private createParticleSystems() {
    // 1. DUST Particles under feet
    const dustCount = 35;
    const dustGeo = new THREE.BufferGeometry();
    const dustPositions = new Float32Array(dustCount * 3);
    for (let i = 0; i < dustCount; i++) {
      dustPositions[i*3] = (Math.random() - 0.5) * 1.5;
      dustPositions[i*3+1] = 0.05 + Math.random() * 0.1;
      dustPositions[i*3+2] = Math.random() * 2.0;
      this.runningParticleVelocity.push((Math.random() - 0.5) * 0.5, 0.1 + Math.random() * 0.5, 2.5 + Math.random() * 2.0);
    }
    dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPositions, 3));
    const dustMat = new THREE.PointsMaterial({
      color: 0x5a4d3c,
      size: 0.16,
      transparent: true,
      opacity: 0.6,
      blending: THREE.NormalBlending
    });
    this.runningParticles = new THREE.Points(dustGeo, dustMat);
    this.scene.add(this.runningParticles);

    // 2. TORCH FLAME SPARKS (Yellow-Red flying up)
    const sparksCount = 120;
    const sparksGeo = new THREE.BufferGeometry();
    const sparkPos = new Float32Array(sparksCount * 3);
    for (let i = 0; i < sparksCount; i++) {
      sparkPos[i*3] = 0;
      sparkPos[i*3+1] = -100; // hide
      sparkPos[i*3+2] = 0;
      this.sparkVelocity.push((Math.random() - 0.5) * 0.4, 0.9 + Math.random() * 1.5, (Math.random() - 0.5) * 0.4);
    }
    sparksGeo.setAttribute('position', new THREE.BufferAttribute(sparkPos, 3));
    const sparksMat = new THREE.PointsMaterial({
      color: 0xffa500,
      size: 0.12,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending
    });
    this.sparksParticles = new THREE.Points(sparksGeo, sparksMat);
    this.scene.add(this.sparksParticles);

    // 3. WIND SPEED TUNNEL LINES (Green/cyan long vectors during speeds)
    const windCount = 80;
    const windGeo = new THREE.BufferGeometry();
    const windPos = new Float32Array(windCount * 3);
    for (let i = 0; i < windCount; i++) {
      windPos[i*3] = (Math.random() - 0.5) * 15;
      windPos[i*3+1] = 0.5 + Math.random() * 12;
      windPos[i*3+2] = -120 - Math.random() * 80;
      this.windVelocity.push(0, 0, 35.0 + Math.random() * 50.0);
    }
    windGeo.setAttribute('position', new THREE.BufferAttribute(windPos, 3));
    const windMat = new THREE.PointsMaterial({
      color: 0x6ee7b7,
      size: 0.18,
      transparent: true,
      opacity: 0.0, // invisible initially
      blending: THREE.AdditiveBlending
    });
    this.windTunnelParticles = new THREE.Points(windGeo, windMat);
    this.scene.add(this.windTunnelParticles);

    // 4. COIN FLASH SPARKLES
    const flashCount = 40;
    const flashGeo = new THREE.BufferGeometry();
    const flashPos = new Float32Array(flashCount * 3);
    for (let i = 0; i < flashCount; i++) {
      flashPos[i*3] = 0;
      flashPos[i*3+1] = -50;
      flashPos[i*3+2] = 0;
    }
    flashGeo.setAttribute('position', new THREE.BufferAttribute(flashPos, 3));
    const flashMat = new THREE.PointsMaterial({
      color: 0xffe066,
      size: 0.28,
      transparent: true,
      opacity: 0.0,
      blending: THREE.AdditiveBlending
    });
    this.collectionFlashParticles = new THREE.Points(flashGeo, flashMat);
    this.scene.add(this.collectionFlashParticles);
  }

  /**
   * Procedural segment design. Generates full rows of ancient pathways, archways, and vegetation
   */
  private generateSegment(zPos: number, index: number, emptySegment = false): THREE.Group {
    const segGroup = new THREE.Group();
    segGroup.position.z = zPos;

    // A. Main Sandfaced Stone Road Platform
    const roadMesh = new THREE.Mesh(this.geometriesList['lane_road'], this.materialsList['road']);
    roadMesh.position.y = -0.6; // flush ground height
    roadMesh.receiveShadow = true;
    segGroup.add(roadMesh);

    // Checkered Stone Lines (Dark and gold mossy panels)
    for (let i = -1; i <= 1; i++) {
      const tileGeo = new THREE.BoxGeometry(this.laneWidth - 0.15, 0.04, this.segmentLength - 0.5);
      const tileMat = new THREE.MeshStandardMaterial({
        color: i === 0 ? 0x27302a : 0x1d2420,
        roughness: 0.95
      });
      const tile = new THREE.Mesh(tileGeo, tileMat);
      tile.position.set(i * this.laneWidth, 0.01, 0);
      tile.receiveShadow = true;
      segGroup.add(tile);
    }

    // B. High Ancient Border Cliffwalls (Left & Right)
    const wallLeft = new THREE.Mesh(this.geometriesList['border_wall'], this.materialsList['mossy_bricks']);
    wallLeft.position.set(-5.6, 1.25, 0);
    wallLeft.castShadow = true;
    wallLeft.receiveShadow = true;
    segGroup.add(wallLeft);

    const wallRight = new THREE.Mesh(this.geometriesList['border_wall'], this.materialsList['mossy_bricks']);
    wallRight.position.set(5.6, 1.25, 0);
    wallRight.castShadow = true;
    wallRight.receiveShadow = true;
    segGroup.add(wallRight);

    // Mossy overgrown border caps
    const borderCapL = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.4, this.segmentLength), this.materialsList['mossy_bricks']);
    borderCapL.position.set(-5.6, 3.1, 0);
    segGroup.add(borderCapL);
    const borderCapR = borderCapL.clone();
    borderCapR.position.x = 5.6;
    segGroup.add(borderCapR);

    // C. SCENERY OVERLAYS (Spawn Trees, Pillars, Torches on borders)
    const itemsCount = 4;
    const spacing = this.segmentLength / itemsCount;

    for (let j = 0; j < itemsCount; j++) {
      const itemZ = -this.segmentLength / 2 + j * spacing + spacing / 2;

      // 1. Left side items (Pots, Jungle Trees, Rocks, Pillars)
      const rollL = Math.random();
      if (rollL < 0.4) {
        // High pillar
        const pillar = new THREE.Mesh(this.geometriesList['pillar'], this.materialsList['mossy_bricks']);
        pillar.position.set(-6.8, 3.0, itemZ);
        pillar.castShadow = true;
        pillar.receiveShadow = true;
        segGroup.add(pillar);

        // Torch Bracket (spawns 1 torch with light!)
        if (Math.random() < 0.5) {
          this.attachWallTorch(segGroup, -5.3, 2.2, itemZ, true);
        }
      } else if (rollL < 0.75) {
        // High pine jungle tree
        const tree = this.createLowPolyTree();
        tree.position.set(-8.5 - Math.random() * 3, 0, itemZ);
        segGroup.add(tree);
      } else {
        // Cliff Rocky Outcrops
        const rock = new THREE.Mesh(this.geometriesList['rock'], this.materialsList['rock_grey']);
        const size = 1.0 + Math.random() * 1.5;
        rock.scale.set(size, size * 1.4, size);
        rock.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, 0);
        rock.position.set(-7.5 - Math.random() * 2, 0.5, itemZ);
        rock.castShadow = true;
        segGroup.add(rock);
      }

      // 2. Right side items
      const rollR = Math.random();
      if (rollR < 0.4) {
        const pillar = new THREE.Mesh(this.geometriesList['pillar'], this.materialsList['mossy_bricks']);
        pillar.position.set(6.8, 3.0, itemZ);
        pillar.castShadow = true;
        pillar.receiveShadow = true;
        segGroup.add(pillar);

        if (Math.random() < 0.5) {
          this.attachWallTorch(segGroup, 5.3, 2.2, itemZ, false);
        }
      } else if (rollR < 0.75) {
        const tree = this.createLowPolyTree();
        tree.position.set(8.5 + Math.random() * 3, 0, itemZ);
        segGroup.add(tree);
      } else {
        const rock = new THREE.Mesh(this.geometriesList['rock'], this.materialsList['rock_grey']);
        const size = 1.0 + Math.random() * 1.5;
        rock.scale.set(size, size * 1.4, size);
        rock.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, 0);
        rock.position.set(7.5 + Math.random() * 2, 0.5, itemZ);
        rock.castShadow = true;
        segGroup.add(rock);
      }
    }

    // D. TEMPLE MONUMENT ARCH (Occurs randomly across segments)
    if (index > 1 && !emptySegment && Math.random() < 0.45) {
      // Ancient portal arch
      const archGroup = new THREE.Group();
      archGroup.position.set(0, 0, 0); // centered inside segment

      const leftPillar = new THREE.Mesh(this.geometriesList['pillar'], this.materialsList['stone_pillar']);
      leftPillar.position.set(-4.8, 3.0, 0);
      leftPillar.castShadow = true;
      archGroup.add(leftPillar);

      const rightPillar = leftPillar.clone();
      rightPillar.position.x = 4.8;
      archGroup.add(rightPillar);

      const topArch = new THREE.Mesh(this.geometriesList['arch_beam'], this.materialsList['stone_pillar']);
      topArch.position.set(0, 6.4, 0);
      topArch.castShadow = true;
      archGroup.add(topArch);

      // Hanging moss or vines
      for (let v = -2; v <= 2; v++) {
        if (Math.random() < 0.6) {
          const vineGeo = new THREE.CylinderGeometry(0.04, 0.04, 1.2 + Math.random() * 1.8, 3);
          const vine = new THREE.Mesh(vineGeo, this.materialsList['leaves']);
          vine.position.set(v * 1.5, 4.8, 0);
          archGroup.add(vine);
        }
      }

      segGroup.add(archGroup);
    }

    // E. COINS & OBSTACLE DISTRIBUTIONS (Only for non-empty paths)
    if (!emptySegment) {
      this.populateSegmentInteractions(segGroup, zPos, index);
    }

    return segGroup;
  }

  private createLowPolyTree(): THREE.Group {
    const tree = new THREE.Group();
    
    // Trunk
    const trunk = new THREE.Mesh(this.geometriesList['tree_trunk'], this.materialsList['tree_wood']);
    trunk.position.y = 6.0;
    trunk.castShadow = true;
    tree.add(trunk);

    // Foliage stacks (cones)
    for (let c = 0; c < 3; c++) {
      const leaves = new THREE.Mesh(this.geometriesList['tree_foliage'], this.materialsList['leaves']);
      leaves.position.y = 8.5 + c * 2.2;
      leaves.scale.set(1 - c * 0.16, 1 - c * 0.16, 1 - c * 0.16);
      leaves.castShadow = true;
      tree.add(leaves);
    }

    return tree;
  }

  private attachWallTorch(toSegment: THREE.Group, x: number, y: number, z: number, isLeft: boolean) {
    const torchBracketGeo = new THREE.BoxGeometry(0.5, 0.16, 0.16);
    const torchHolder = new THREE.Mesh(torchBracketGeo, this.materialsList['rock_grey']);
    torchHolder.position.set(x, y, z);
    
    const woodGeo = new THREE.CylinderGeometry(0.06, 0.06, 0.6, 5);
    const wood = new THREE.Mesh(woodGeo, this.materialsList['tree_wood']);
    wood.position.set(isLeft ? 0.25 : -0.25, 0.25, 0);
    wood.rotation.z = isLeft ? -0.45 : 0.45;
    torchHolder.add(wood);

    // Flame Core (little glowing sphere)
    const flameGeo = new THREE.SphereGeometry(0.18, 5, 5);
    const flameMat = new THREE.MeshBasicMaterial({ color: 0xff4500 });
    const flame = new THREE.Mesh(flameGeo, flameMat);
    flame.position.set(0, 0.35, 0);
    wood.add(flame);

    // Warm Flickering Torch light
    if (this.torchLights.length < 12) { // Limit lights for performance
      const light = new THREE.PointLight(0xff6600, 1.6, 15);
      light.position.set(x + (isLeft ? 0.4 : -0.4), y + 0.6, z);
      light.castShadow = false; // Point light shadows disabled for high FPS
      toSegment.add(light);
      this.torchLights.push(light);
    }

    toSegment.add(torchHolder);
  }

  /**
   * Randomized placement of coins, spikes, rolling stones, gaps, or shields
   */
  private populateSegmentInteractions(toSegment: THREE.Group, absoluteZ: number, index: number) {
    const obstacleLanes: Lane[] = [-1, 0, 1];
    
    // Choose segment layout
    // 1: Clear, but coins in lines/waves
    // 2: Spikes / Obstacles blocking 1-2 lanes, with coins guiding the safe path
    // 3: Floating power up inside high barrier slide path or low obstacle jump path
    const layout = Math.random();

    if (layout < 0.28) {
      // 1. COIN LINES (no obstacles)
      const selectedLane = obstacleLanes[Math.floor(Math.random() * obstacleLanes.length)];
      const doubleCoins = Math.random() < 0.4;
      const secondSelectedLane = obstacleLanes.find(l => l !== selectedLane) || 0;

      this.spawnCoinRow(toSegment, selectedLane, -15, 15, 5, false, absoluteZ);
      if (doubleCoins) {
        this.spawnCoinRow(toSegment, secondSelectedLane, -15, 15, 5, false, absoluteZ);
      }
    } 
    else if (layout < 0.78) {
      // 2. OBSTACLE HAZARDS + SAFE-LANE COINS
      // Determine what obstacle to spawn
      const obsTypeRoll = Math.random();
      let obstacleType: ObstacleType = 'SPIKES';
      
      if (obsTypeRoll < 0.35) obstacleType = 'SPIKES';
      else if (obsTypeRoll < 0.62) obstacleType = 'BARRIER_LOW';
      else if (obsTypeRoll < 0.85) obstacleType = 'BARRIER_HIGH';
      else obstacleType = 'ROLLING_ROCK';

      const obstacleLane = obstacleLanes[Math.floor(Math.random() * obstacleLanes.length)] as Lane;

      this.createObstacle(toSegment, obstacleType, obstacleLane, absoluteZ);

      // Safe lane coins: guide the player
      const safeLane = obstacleLanes.find(l => l !== obstacleLane) || 0;
      this.spawnCoinRow(toSegment, safeLane, -12, 12, 4, false, absoluteZ);

      // Rare chance of powerup in another safe lane
      if (Math.random() < 0.08) {
        const powerupLane = obstacleLanes.find(l => l !== obstacleLane && l !== safeLane);
        if (powerupLane !== undefined) {
          this.createPowerUp(toSegment, powerupLane, 0, absoluteZ);
        }
      }
    } 
    else {
      // 3. ARCHWAY SLIDERS / GAP LEAPERS
      const dualObstacle = Math.random() < 0.55;
      
      if (dualObstacle) {
        // High barrier spanning center, spikes left, clear right
        const layoutType = Math.random();
        if (layoutType < 0.33) {
          this.createObstacle(toSegment, 'BARRIER_HIGH', 0, absoluteZ);
          this.createObstacle(toSegment, 'SPIKES', -1, absoluteZ);
          // Spawn powerup right!
          this.createPowerUp(toSegment, 1, 0, absoluteZ);
        } else if (layoutType < 0.66) {
          this.createObstacle(toSegment, 'BARRIER_LOW', -1, absoluteZ);
          this.createObstacle(toSegment, 'BARRIER_LOW', 0, absoluteZ);
          // Safe lane right with high coin curve
          this.spawnCoinRow(toSegment, 1, -8, 8, 3, true, absoluteZ);
        } else {
          // Double lane blocks
          this.createObstacle(toSegment, 'SPIKES', 0, absoluteZ);
          this.createObstacle(toSegment, 'SPIKES', 1, absoluteZ);
          // Coin curve guide on left jumping
          this.spawnCoinRow(toSegment, -1, -10, 10, 3, true, absoluteZ);
        }
      } else {
        // Individual powerup centered in the segment floating beautifully within gold sparks
        const randomLane = obstacleLanes[Math.floor(Math.random() * obstacleLanes.length)];
        this.createPowerUp(toSegment, randomLane, 0, absoluteZ);
        this.spawnCoinRow(toSegment, randomLane, -15, 15, 4, true, absoluteZ);
      }
    }
  }

  private spawnCoinRow(toSegment: THREE.Group, lane: Lane, startZ: number, endZ: number, count: number, arcEffect: boolean, segmentAbsoluteZ: number) {
    const spacing = (endZ - startZ) / (count - 1);
    
    for (let c = 0; c < count; c++) {
      const zOffset = startZ + c * spacing;
      
      // Arc formula calculates higher Y for coins in center to guide jumping
      let coinY = 0.5;
      if (arcEffect) {
        const ratio = c / (count - 1); // 0 to 1
        coinY = 0.5 + Math.sin(ratio * Math.PI) * 2.3;
      }

      const coinMesh = new THREE.Mesh(this.geometriesList['coin'], this.materialsList['gold_coin']);
      coinMesh.position.set(lane * this.laneWidth, coinY, zOffset);
      coinMesh.rotation.y = Math.random() * Math.PI;
      coinMesh.castShadow = true;
      toSegment.add(coinMesh);

      // Track Index of child
      const absoluteZLoc = segmentAbsoluteZ + zOffset;
      const meshIndex = toSegment.children.length - 1;

      this.activeCoins.push({
        id: `coin_${segmentAbsoluteZ}_${lane}_${c}`,
        lane,
        z: absoluteZLoc,
        y: coinY,
        meshIndex,
        collected: false
      });
      
      this.coinsMeshes.push(coinMesh);
    }
  }

  private createObstacle(toSegment: THREE.Group, type: ObstacleType, lane: Lane, segmentAbsoluteZ: number) {
    let obstacleMesh: THREE.Object3D;
    const xPos = lane * this.laneWidth;

    if (type === 'SPIKES') {
      const spikesGroup = new THREE.Group();
      // Grid of 5 spike cones
      for (let s = -2; s <= 2; s++) {
        const spike = new THREE.Mesh(this.geometriesList['spikes'], this.materialsList['spikes_metallic']);
        spike.position.set(s * 0.5, 0.45, 0);
        spike.castShadow = true;
        spikesGroup.add(spike);
      }
      // wooden border
      const border = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.22, 1.2), this.materialsList['tree_wood']);
      border.position.set(0, 0.1, 0);
      border.receiveShadow = true;
      spikesGroup.add(border);
      
      spikesGroup.position.set(xPos, 0.0, 0); // segment center Z = 0
      obstacleMesh = spikesGroup;
    }
    else if (type === 'BARRIER_LOW') {
      // Fallen tree log
      const logGroup = new THREE.Group();
      const log = new THREE.Mesh(this.geometriesList['barrier_low'], this.materialsList['tree_wood']);
      log.rotation.z = 0.05 * (Math.random() - 0.5);
      log.castShadow = true;
      logGroup.add(log);

      // supports
      const branchL = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 1.4), this.materialsList['tree_wood']);
      branchL.position.set(-2.8, -0.4, 0);
      branchL.castShadow = true;
      logGroup.add(branchL);
      const branchR = branchL.clone();
      branchR.position.x = 2.8;
      logGroup.add(branchR);

      // spikes / moss
      const foliage = new THREE.Mesh(new THREE.SphereGeometry(0.5, 4, 4), this.materialsList['leaves']);
      foliage.position.set(1.5, 0.4, 0);
      foliage.scale.set(1, 0.4, 1.4);
      logGroup.add(foliage);

      logGroup.position.set(xPos, 0.62, 0);
      obstacleMesh = logGroup;
    }
    else if (type === 'BARRIER_HIGH') {
      // Overhanging mossy temple arch or heavy branch
      const archGroup = new THREE.Group();
      const beam = new THREE.Mesh(this.geometriesList['barrier_high'], this.materialsList['mossy_bricks']);
      beam.castShadow = true;
      archGroup.add(beam);

      // Warning hazard colors on beam (yellow hazard lines)
      const warningStrip = new THREE.Mesh(new THREE.BoxGeometry(8.0, 0.15, 0.75), this.materialsList['obstacle_hazard']);
      warningStrip.position.set(0, -0.3, 0.01);
      archGroup.add(warningStrip);

      // Left support on wall
      const wallLegL = new THREE.Mesh(new THREE.BoxGeometry(0.4, 4.5, 0.7), this.materialsList['mossy_bricks']);
      wallLegL.position.set(-4.2, -2.0, 0);
      archGroup.add(wallLegL);

      const wallLegR = wallLegL.clone();
      wallLegR.position.x = 4.2;
      archGroup.add(wallLegR);

      archGroup.position.set(0, 2.5, 0); // Spans multiple lanes because it's center anchored
      obstacleMesh = archGroup;
    }
    else {
      // ROLLING_ROCK: A giant spherical boulder boulder that begins in center and rolls
      obstacleMesh = new THREE.Mesh(this.geometriesList['rock'], this.materialsList['rock_grey']);
      obstacleMesh.position.set(xPos, 1.5, 0);
      obstacleMesh.scale.set(1.1, 1.1, 1.1);
      obstacleMesh.castShadow = true;
    }

    toSegment.add(obstacleMesh);
    const meshIndex = toSegment.children.length - 1;

    this.activeObstacles.push({
      id: `obstacle_${segmentAbsoluteZ}_${lane}_${type}`,
      type,
      lane,
      meshIndex,
      z: segmentAbsoluteZ
    });
    this.obstacleMeshes.push(obstacleMesh);
  }

  private createPowerUp(toSegment: THREE.Group, lane: Lane, zOffset: number, segmentAbsoluteZ: number) {
    const obstacleLanes: PowerUpType[] = ['MAGNET', 'SHIELD', 'BOOST'];
    const type = obstacleLanes[Math.floor(Math.random() * obstacleLanes.length)];

    let geo = this.geometriesList['shield_powerup'];
    let mat = this.materialsList['shield'];
    
    if (type === 'MAGNET') {
      geo = this.geometriesList['magnet_powerup'];
      mat = this.materialsList['magnet'];
    } else if (type === 'BOOST') {
      geo = this.geometriesList['boost_powerup'];
      mat = this.materialsList['boost'];
    }

    const itemGroup = new THREE.Group();
    
    // Core powerup item
    const iconMesh = new THREE.Mesh(geo, mat);
    iconMesh.castShadow = true;
    if (type === 'MAGNET') {
      iconMesh.rotation.x = Math.PI / 2;
    }
    itemGroup.add(iconMesh);

    // Glowing halo ring around it
    const ringGeo = new THREE.RingGeometry(0.8, 0.95, 8);
    const ringMat = new THREE.MeshBasicMaterial({
      color: type === 'MAGNET' ? 0xef4444 : (type === 'SHIELD' ? 0x0ea5e9 : 0x22c55e),
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.65
    });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = -0.1;
    itemGroup.add(ring);

    // subtle floating point light for intense retro game feeling
    if (this.torchLights.length < 12) {
      const pLight = new THREE.PointLight(ringMat.color.getHex(), 1.0, 6);
      pLight.position.set(0, 0.5, 0);
      itemGroup.add(pLight);
    }

    itemGroup.position.set(lane * this.laneWidth, 1.25, zOffset);
    toSegment.add(itemGroup);
    
    const meshIndex = toSegment.children.length - 1;

    this.activePowerUps.push({
      id: `pw_${segmentAbsoluteZ}_${lane}_${type}`,
      type,
      lane,
      z: segmentAbsoluteZ + zOffset,
      meshIndex,
      collected: false
    });
    this.powerUpMeshes.push(itemGroup);
    
    // Quick sound effect when spawning a power up nearby
    audio.playMagnetStatic();
  }

  private generateInitialSegments() {
    this.lastSegmentZ = 0;
    this.segmentIndexCounter = 0;

    for (let i = 0; i < this.segmentsAhead; i++) {
      // First 2 segments are strictly empty so player starts safely with zero jump/dodge fatigue
      const empty = i < 3;
      const seg = this.generateSegment(this.lastSegmentZ, this.segmentIndexCounter, empty);
      this.scene.add(seg);
      this.segments.push(seg);
      
      this.lastSegmentZ -= this.segmentLength; // run forward down -Z axis
      this.segmentIndexCounter++;
    }
  }

  /**
   * Main game running loop
   */
  private animate = () => {
    this.animationFrameId = requestAnimationFrame(this.animate);

    const dt = Math.min(this.clock.getDelta(), 0.1); // cap dt to avoid crazy warps
    
    if (this.gamePhase === 'PLAYING') {
      if (this.isInvulnerable) {
        this.invulnerableTimer -= dt;
        if (this.invulnerableTimer <= 0) {
          this.isInvulnerable = false;
          this.playerGroup.visible = true;
        } else {
          // Flash player visibility to indicate recovery active
          this.playerGroup.visible = Math.floor(this.invulnerableTimer * 10) % 2 === 0;
        }
      }

      this.updatePlayerPhysics(dt);
      this.recycleSegments();
      this.updateEnvironmentAnimations(dt);
      this.checkCollisions(dt);
      this.updateParticles(dt);
      this.updateScores(dt);
      this.syncRadarData();
    } else {
      this.playerGroup.visible = true; // Safe fallback when not in playing phase
      if (this.gamePhase === 'START') {
        this.updateStartScreenAnimations(dt);
      } else if (this.gamePhase === 'GAMEOVER') {
        this.updateGameOverFall(dt);
      }
    }

    this.updateCameraSystem(dt);
    
    this.renderer.render(this.scene, this.camera);
  };

  private updateStartScreenAnimations(dt: number) {
    // Explorer bobbing up and down gracefully matching deep breaths
    const time = this.clock.getElapsedTime();
    this.playerGroup.position.y = Math.sin(time * 2.2) * 0.08;
    this.playerGroup.position.x = 0;
    this.playerGroup.position.z = 0;

    // Limb subtle breathing
    this.playerLeftArm.rotation.x = Math.sin(time * 2.2) * 0.12;
    this.playerRightArm.rotation.x = -Math.sin(time * 2.2) * 0.12;

    // Idle rotate camera very slowly around starting player
    const orbitRadius = 11.5;
    this.camera.position.x = Math.sin(time * 0.3) * orbitRadius;
    this.camera.position.z = Math.cos(time * 0.3) * orbitRadius + 1.0;
    this.camera.position.y = 4.2 + Math.sin(time * 0.5) * 0.5;
    this.camera.lookAt(0, 1.1, 0);

    // Keep road glowing
    this.updateEnvironmentAnimations(dt);
  }

  private updatePlayerPhysics(dt: number) {
    const time = this.clock.getElapsedTime();

    // 1. Move player forward automatically down Z-axis
    const currentSpeed = this.runSpeed * this.speedMultiplier;
    this.playerGroup.position.z -= currentSpeed * dt;
    this.runDistance = -this.playerGroup.position.z;

    // 2. Adjust lane transitions smoothly via Lerp
    this.targetLaneX = this.playerLane * this.laneWidth;
    this.playerGroup.position.x = THREE.MathUtils.lerp(this.playerGroup.position.x, this.targetLaneX, 14.5 * dt);

    // banking rotation tilt when steer-sliding
    const targetRoll = (this.playerGroup.position.x - this.targetLaneX) * 0.14;
    this.playerGroup.rotation.z = THREE.MathUtils.lerp(this.playerGroup.rotation.z, targetRoll, 10 * dt);
    this.playerGroup.rotation.y = THREE.MathUtils.lerp(this.playerGroup.rotation.y, -targetRoll * 0.4, 10 * dt);

    // 3. JUMP MATH
    if (this.isJumping) {
      this.jumpTimer += dt;
      const progress = this.jumpTimer / this.jumpDuration;
      
      if (progress >= 1.0) {
        this.isJumping = false;
        this.playerGroup.position.y = 0;
        this.jumpTimer = 0;
      } else {
        // High parabolic path
        this.playerGroup.position.y = Math.sin(progress * Math.PI) * this.jumpHeight;
        
        // Jumping pose (tuck boots and lift arms)
        this.playerLeftLeg.rotation.x = -0.5;
        this.playerRightLeg.rotation.x = -0.5;
        this.playerLeftArm.rotation.x = -Math.PI + 0.3;
        this.playerRightArm.rotation.x = -Math.PI + 0.3;
      }
    }

    // 4. SLIDE MATH
    else if (this.isSliding) {
      this.slideTimer += dt;
      const progress = this.slideTimer / this.slideDuration;

      if (progress >= 1.0) {
        this.isSliding = false;
        this.slideTimer = 0;
        // Restore scale
        this.playerBody.scale.set(1.0, 1.0, 1.0);
        this.playerBody.position.y = 1.15;
      } else {
        // Flatten torso and move legs up
        this.playerBody.scale.set(1.0, 0.45, 1.0);
        this.playerBody.position.y = 0.45;

        this.playerLeftLeg.rotation.x = Math.PI / 2;
        this.playerRightLeg.rotation.x = Math.PI / 2;
        this.playerLeftArm.rotation.x = Math.PI / 2;
        this.playerRightArm.rotation.x = Math.PI / 2;
      }
    }

    // 5. RUNNING ANIMS OR IDLE (if not jumped/slided)
    if (!this.isJumping && !this.isSliding) {
      // Running arms/legs swings cycles matching real explorer gait
      const cycleSpeed = this.isBoostActive ? 23.0 : (10.0 + this.runSpeed * 0.2);
      const angleSwing = Math.sin(time * cycleSpeed);
      
      this.playerLeftLeg.rotation.x = angleSwing * 0.55;
      this.playerRightLeg.rotation.x = -angleSwing * 0.55;
      
      this.playerLeftArm.rotation.x = -angleSwing * 0.55;
      this.playerRightArm.rotation.x = angleSwing * 0.55;
      
      // subtle shoulder bounce
      this.playerBody.position.y = 1.15 + Math.abs(angleSwing) * 0.07;
      this.playerHead.position.y = 0.82 + Math.cos(time * cycleSpeed) * 0.03;
    }

    // 6. POWER-UP TIMERS
    if (this.activePowerUp) {
      this.powerUpTimer -= dt * 1000;
      const pct = Math.max(0, this.powerUpTimer / this.powerUpDurationMax);
      this.onPowerUpActive(this.activePowerUp, pct);

      // Power-up visual spinning bubble / glows
      if (this.isShieldActive && this.shieldBubbleMesh) {
        this.shieldBubbleMesh.visible = true;
        this.shieldBubbleMesh.rotation.y += dt * 3.5;
        this.shieldBubbleMesh.rotation.x += dt * 1.5;
        
        // breathing glow effect
        const opacity = 0.5 + Math.sin(time * 12.0) * 0.15;
        (this.shieldBubbleMesh.material as THREE.Material).opacity = opacity;
      }

      if (this.powerUpTimer <= 0) {
        this.deactivateAllPowerUps();
      }
    }

    // 7. SPEED ACCELERATION OVER TIME
    if (!this.isBoostActive) {
      this.runSpeed = Math.min(this.runSpeed + this.acceleration * dt, this.maxRunSpeed);
    }
  }

  private deactivateAllPowerUps() {
    this.activePowerUp = null;
    this.isShieldActive = false;
    this.isMagnetActive = false;
    this.isBoostActive = false;
    this.speedMultiplier = 1.0;
    
    if (this.shieldBubbleMesh) {
      this.shieldBubbleMesh.visible = false;
    }
    
    // Turn down speedlines particle opacity
    (this.windTunnelParticles.material as THREE.PointsMaterial).opacity = 0.0;
    this.onPowerUpActive(null, 0);
  }

  private updateEnvironmentAnimations(dt: number) {
    // 1. Spinning coins
    for (let i = 0; i < this.coinsMeshes.length; i++) {
      const mesh = this.coinsMeshes[i];
      if (mesh) {
        mesh.rotation.z += dt * 3.2; // spin coins
      }
    }

    // 2. Rotating active Powerup items on paths
    for (let c = 0; c < this.powerUpMeshes.length; c++) {
      const mesh = this.powerUpMeshes[c];
      if (mesh) {
        mesh.rotation.y += dt * 2.2;
        mesh.position.y = 1.25 + Math.sin(this.clock.getElapsedTime() * 4.0 + c) * 0.15;
      }
    }

    // 3. Flicker Torchlights random intensity so ancient tomb sparks feels real
    for (const light of this.torchLights) {
      light.intensity = 1.25 + Math.random() * 0.7;
    }
  }

  /**
   * Moves behind player and recycles spent backward paths to make them endless
   */
  private recycleSegments() {
    const firstSegment = this.segments[0];
    const playerZ = this.playerGroup.position.z;

    // segment length is 40.0. If player has run past first segment center, recycle it!
    if (playerZ < firstSegment.position.z - this.segmentLength * 1.5) {
      // 1. Remove first segment from scene
      const recycled = this.segments.shift()!;
      this.scene.remove(recycled);

      // Clean up child lights, coins or powerups from global lists to avoid bloating
      recycled.traverse(child => {
        if (child instanceof THREE.PointLight) {
          const idx = this.torchLights.indexOf(child);
          if (idx !== -1) this.torchLights.splice(idx, 1);
        } else {
          // Remove from coinsMeshes index to prevent memory leak and slow animations
          const cIdx = this.coinsMeshes.indexOf(child);
          if (cIdx !== -1) this.coinsMeshes.splice(cIdx, 1);

          // Remove from powerUpMeshes index to prevent memory leak and slow animations
          const pIdx = this.powerUpMeshes.indexOf(child);
          if (pIdx !== -1) this.powerUpMeshes.splice(pIdx, 1);
        }
      });

      // 2. Generate new future segment further ahead
      const nextZ = this.lastSegmentZ;
      const seg = this.generateSegment(nextZ, this.segmentIndexCounter, false);
      this.scene.add(seg);
      this.segments.push(seg);

      // 3. Update indices and clear spent obstacles/coins from out-of-sight Z boundaries
      this.lastSegmentZ -= this.segmentLength;
      this.segmentIndexCounter++;

      const purgeZThreshold = playerZ + 45.0; // purges everything 45 units behind explorer
      this.cleanOldInteractions(purgeZThreshold);
    }
  }

  private cleanOldInteractions(purgeZ: number) {
    // Coins
    this.activeCoins = this.activeCoins.filter(c => c.z < purgeZ);

    // Powerups
    this.activePowerUps = this.activePowerUps.filter(pw => pw.z < purgeZ);

    // Obstacles
    this.activeObstacles = this.activeObstacles.filter(o => o.z < purgeZ);
  }

  private checkCollisions(dt: number) {
    const playerZ = this.playerGroup.position.z;
    const playerX = this.playerGroup.position.x;
    const playerY = this.playerGroup.position.y;

    const crashDistance = 1.6; // distance threshold for box intersection
    
    // 1. COIN COLLECTION & MAGNET LOGIC
    for (let i = 0; i < this.activeCoins.length; i++) {
      const coin = this.activeCoins[i];
      if (coin.collected) continue;

      let coinX = coin.lane * this.laneWidth;
      let coinY = coin.y;
      let coinZ = coin.z;

      const baseDz = coin.z - playerZ;
      let distanceToPlayer = Math.sqrt(baseDz * baseDz + (coinX - playerX) * (coinX - playerX) + (coinY - playerY) * (coinY - playerY));

      // A. MAGNET PULL EFFECT
      if (this.isMagnetActive && distanceToPlayer < 28.0) {
        if (coin.animX === undefined) coin.animX = coinX;
        if (coin.animY === undefined) coin.animY = coinY;
        if (coin.animZ === undefined) coin.animZ = coinZ;

        // Smoothly accelerate coin pull towards player as it gets closer
        const pullSpeed = distanceToPlayer < 10.0 ? 22.0 : 16.0;
        coin.animX = THREE.MathUtils.lerp(coin.animX, playerX, pullSpeed * dt);
        coin.animY = THREE.MathUtils.lerp(coin.animY, playerY + 0.8, pullSpeed * dt);
        coin.animZ = THREE.MathUtils.lerp(coin.animZ, playerZ, pullSpeed * dt);

        coinX = coin.animX;
        coinY = coin.animY;
        coinZ = coin.animZ;

        // Recalculate accurate dynamic distance for collection trigger
        const animatedDz = coinZ - playerZ;
        distanceToPlayer = Math.sqrt(animatedDz * animatedDz + (coinX - playerX) * (coinX - playerX) + (coinY - playerY) * (coinY - playerY));

        // Find the hosting segment and update its child mesh position to match
        const indexSeg = this.segments.find(s => Math.abs(s.position.z - coin.z) <= 20.0);
        if (indexSeg && indexSeg.children[coin.meshIndex]) {
          const coinMeshLocal = indexSeg.children[coin.meshIndex];
          this.reusableVector3.set(coinX, coinY, coinZ);
          const localTarget = indexSeg.worldToLocal(this.reusableVector3);
          coinMeshLocal.position.copy(localTarget);
        }
      }

      // B. COLLECTION TRIGGER
      if (distanceToPlayer < 1.6) {
        coin.collected = true;
        this.coinCount++;
        this.onCoinsUpdate(this.coinCount);
        audio.playCoin();
        
        // Render sparkle particles at collection spot
        this.triggerCollectionSparkles(playerX, playerY + 0.8, playerZ);

        // Hide mesh from Three.js scene
        const segmentMesh = this.segments.find(s => Math.abs(s.position.z - coin.z) <= 20.0);
        if (segmentMesh && segmentMesh.children[coin.meshIndex]) {
          const m = segmentMesh.children[coin.meshIndex];
          m.visible = false;
          // Also strip from coinsMeshes array early to save animation render cycles
          const cIdx = this.coinsMeshes.indexOf(m);
          if (cIdx !== -1) {
            this.coinsMeshes.splice(cIdx, 1);
          }
        }
      }
    }

    // 2. POWER UPS COLLECTION
    for (let p = 0; p < this.activePowerUps.length; p++) {
      const pw = this.activePowerUps[p];
      if (pw.collected) continue;

      const dz = pw.z - playerZ;
      const pwX = pw.lane * this.laneWidth;
      const distance = Math.sqrt(dz*dz + (pwX - playerX)*(pwX - playerX));

      if (distance < 1.7) {
        pw.collected = true;
        this.triggerPowerUp(pw.type);

        // Hide mesh
        const segmentZOffset = Math.floor((pw.z + this.segmentLength/2) / this.segmentLength) * this.segmentLength;
        const segmentMesh = this.segments.find(s => Math.abs(s.position.z - segmentZOffset) < 0.2);
        if (segmentMesh && segmentMesh.children[pw.meshIndex]) {
          const m = segmentMesh.children[pw.meshIndex];
          m.visible = false;
          // Also strip from powerUpMeshes early to save animation render cycles
          const pIdx = this.powerUpMeshes.indexOf(m);
          if (pIdx !== -1) {
            this.powerUpMeshes.splice(pIdx, 1);
          }
        }
      }
    }

    // 3. OBSTACLE COLLISION MAP (No collision if boosted/invincible!)
    if (this.isBoostActive) return;

    for (let o = 0; o < this.activeObstacles.length; o++) {
      const obs = this.activeObstacles[o];
      
      // Look for the specific segment containing the obstacle using its absolute Z coordinate (obs.z)
      const segmentMesh = this.segments.find(s => Math.abs(s.position.z - obs.z) < 1.0);
      if (!segmentMesh) continue;

      const obsMesh = segmentMesh.children[obs.meshIndex];
      if (!obsMesh || !obsMesh.visible) continue;

      const absObsZ = obs.z;

      // Distance checking
      const dz = Math.abs(absObsZ - playerZ);
      const dx = Math.abs((obs.lane * this.laneWidth) - playerX);

      // Check collision window
      if (dz < 1.4 && dx < 1.1) {
        // Z & X lanes intersect! Now verify vertical clearance (jumping/sliding thresholds)
        let collisionTriggered = false;

        if (obs.type === 'SPIKES' || obs.type === 'BARRIER_LOW') {
          // Ground hurdle: Player MUST be jumping of significant height
          if (!this.isJumping || playerY < 1.0) {
            collisionTriggered = true;
          }
        } 
        else if (obs.type === 'BARRIER_HIGH') {
          // High wall spanning all lanes: Player MUST slide close to ground
          if (!this.isSliding) {
            collisionTriggered = true;
          }
        }
        else if (obs.type === 'ROLLING_ROCK') {
          // Heavy rock: Player can leap completely or shift lane
          if (playerY < 1.3) {
            collisionTriggered = true;
          }
        }

        if (collisionTriggered) {
          if (this.isInvulnerable) return; // Prevent double hits in invulnerability period

          // SHIELD INTERCEPT
          if (this.isShieldActive) {
            this.deactivateAllPowerUps();
            audio.playShieldBreak();
            obsMesh.visible = false; // Destroy obstacle mesh on impact
            this.cameraShakeIntensity = 0.55; // Screen shake feedback
            return;
          }

          // Subtract 1 life
          this.lives--;
          this.onLivesUpdate(this.lives);

          // Force-destroy the collided obstacle mesh so the player doesn't run into it again
          obsMesh.visible = false;
          
          // Camera punch feedback
          this.cameraShakeIntensity = 0.85;

          if (this.lives <= 0) {
            // CRITICAL CRASH GAME OVER
            this.triggerCrash();
          } else {
            // Play hurt grunt audio feedback
            audio.playHurt();
            
            // Go invulnerable for immediate recovery state
            this.isInvulnerable = true;
            this.invulnerableTimer = this.invulnerableDurationMax;
          }
        }
      }
    }
  }

  private triggerPowerUp(type: PowerUpType) {
    audio.playPowerUp();
    this.deactivateAllPowerUps(); // Turn off previous powerup to avoid overlaps

    this.activePowerUp = type;
    this.powerUpTimer = this.powerUpDurationMax;

    if (type === 'SHIELD') {
      this.isShieldActive = true;
      if (this.shieldBubbleMesh) this.shieldBubbleMesh.visible = true;
    }
    else if (type === 'MAGNET') {
      this.isMagnetActive = true;
    }
    else if (type === 'BOOST') {
      this.isBoostActive = true;
      this.speedMultiplier = 2.1; // Blitz speed multiplier!
      audio.playSpeedBoost();

      // Wind speedlines particle visible
      (this.windTunnelParticles.material as THREE.PointsMaterial).opacity = 0.45;
    }
  }

  private triggerCrash() {
    if (this.isCrashed) return;

    this.isCrashed = true;
    this.crashTimer = 0;
    this.gamePhase = 'GAMEOVER';
    
    audio.playCrash();
    audio.stopMusic();

    // Trigger state change
    this.onGamePhaseChange('GAMEOVER');

    // Save final stats and adjust highscore
    this.stats.score = Math.floor(this.runDistance);
    this.stats.coins = this.coinCount;
    this.stats.totalCoins += this.coinCount;

    if (this.stats.score > this.stats.highScore) {
      this.stats.highScore = this.stats.score;
      localStorage.setItem('temple_runner_high_score', this.stats.score.toString());
    }
    localStorage.setItem('temple_runner_total_coins', this.stats.totalCoins.toString());

    this.onStatsSync(this.stats);
  }

  private updateGameOverFall(dt: number) {
    this.crashTimer += dt;
    
    // Rotate explorer head backwards, trip body down
    this.playerGroup.rotation.x = THREE.MathUtils.lerp(this.playerGroup.rotation.x, -Math.PI / 2, 4.5 * dt);
    this.playerGroup.position.y = THREE.MathUtils.lerp(this.playerGroup.position.y, 0.15, 6 * dt);
    
    this.cameraShakeIntensity = Math.max(0, 0.6 - this.crashTimer * 0.82);

    // rotate limbs backward
    this.playerLeftArm.rotation.x = -1.5;
    this.playerRightArm.rotation.x = -1.5;
  }

  /**
   * Spits dust under heels, trails sparkling fires, and blows speeds
   */
  private updateParticles(dt: number) {
    // 1. Footstep dust lines
    const dustPosAttr = this.runningParticles.geometry.getAttribute('position') as THREE.BufferAttribute;
    const dustPos = dustPosAttr.array as Float32Array;
    const playerZ = this.playerGroup.position.z;
    const playerX = this.playerGroup.position.x;
    const playerY = this.playerGroup.position.y;

    for (let i = 0; i < dustPos.length / 3; i++) {
      // Move dust back relative to runner
      dustPos[i*3] += this.runningParticleVelocity[i*3] * dt;
      dustPos[i*3+1] += this.runningParticleVelocity[i*3+1] * dt;
      dustPos[i*3+2] += this.runningParticleVelocity[i*3+2] * dt;

      // Lower opacity or fade running dust
      if (dustPos[i*3+2] > 7.0 || dustPos[i*3+1] > 1.2 || this.isJumping) {
        // Recycle dust back under feet
        dustPos[i*3] = playerX + (Math.random() - 0.5) * 0.6;
        dustPos[i*3+1] = playerY + 0.05;
        dustPos[i*3+2] = playerZ + 0.1;
      }
    }
    dustPosAttr.needsUpdate = true;

    // 2. Torches flame sparkles
    const sparkPosAttr = this.sparksParticles.geometry.getAttribute('position') as THREE.BufferAttribute;
    const sparkPos = sparkPosAttr.array as Float32Array;

    // Find closest torches to player to feed particle positions (maximum performance)
    const torchesCount = this.torchLights.length;
    if (torchesCount > 0) {
      for (let i = 0; i < sparkPos.length / 3; i++) {
        // Apply velocity upward
        sparkPos[i*3] += this.sparkVelocity[i*3] * dt;
        sparkPos[i*3+1] += this.sparkVelocity[i*3+1] * dt;
        sparkPos[i*3+2] += this.sparkVelocity[i*3+2] * dt;

        // Reset spark at a random active torch scene coordinate
        if (Math.random() < 0.04 || sparkPos[i*3+1] > 6.0) {
          const randomTorch = this.torchLights[Math.floor(Math.random() * torchesCount)];
          // find world position of torch source
          const parentSeg = randomTorch.parent;
          if (parentSeg) {
            const worldPos = new THREE.Vector3();
            randomTorch.getWorldPosition(worldPos);
            sparkPos[i*3] = worldPos.x + (Math.random() - 0.5) * 0.1;
            sparkPos[i*3+1] = worldPos.y + 0.1;
            sparkPos[i*3+2] = worldPos.z;
          }
        }
      }
      sparkPosAttr.needsUpdate = true;
    }

    // 3. Speed windfall booster streaks
    if (this.isBoostActive) {
      const windPosAttr = this.windTunnelParticles.geometry.getAttribute('position') as THREE.BufferAttribute;
      const windPos = windPosAttr.array as Float32Array;

      for (let i = 0; i < windPos.length / 3; i++) {
        windPos[i*3+2] += this.windVelocity[i*3+2] * dt * 2.5; // blitz forward

        if (windPos[i*3+2] > playerZ + 15.0) {
          // Respawn far ahead
          windPos[i*3] = playerX + (Math.random() - 0.5) * 16;
          windPos[i*3+1] = playerY + 0.5 + Math.random() * 8;
          windPos[i*3+2] = playerZ - 90 - Math.random() * 60;
        }
      }
      windPosAttr.needsUpdate = true;
    }

    // 4. Coin Collect flashes fading
    const pMat = this.collectionFlashParticles.material as THREE.PointsMaterial;
    if (pMat.opacity > 0) {
      pMat.opacity -= dt * 2.5;
      const flashPosAttr = this.collectionFlashParticles.geometry.getAttribute('position') as THREE.BufferAttribute;
      const flashPos = flashPosAttr.array as Float32Array;
      for (let i = 0; i < flashPos.length / 3; i++) {
        flashPos[i*3] += (Math.random() - 0.5) * 4.5 * dt;
        flashPos[i*3+1] += (Math.random() - 0.1) * 3.5 * dt;
        flashPos[i*3+2] += (Math.random() - 0.5) * 4.5 * dt;
      }
      flashPosAttr.needsUpdate = true;
    }
  }

  private triggerCollectionSparkles(x: number, y: number, z: number) {
    const flashPosAttr = this.collectionFlashParticles.geometry.getAttribute('position') as THREE.BufferAttribute;
    const flashPos = flashPosAttr.array as Float32Array;
    const pMat = this.collectionFlashParticles.material as THREE.PointsMaterial;
    
    pMat.opacity = 0.95;

    for (let i = 0; i < flashPos.length / 3; i++) {
      flashPos[i*3] = x + (Math.random() - 0.5) * 0.8;
      flashPos[i*3+1] = y + (Math.random() - 0.5) * 0.8;
      flashPos[i*3+2] = z + (Math.random() - 0.5) * 0.8;
    }
    flashPosAttr.needsUpdate = true;
  }

  private updateScores(dt: number) {
    this.stats.score = Math.floor(this.runDistance);
    this.onScoreUpdate(this.stats.score);

    // Multiplier tracks speed levels
    const targetMult = 1 + Math.floor(this.runSpeed / 12);
    if (this.stats.multiplier !== targetMult) {
      this.stats.multiplier = targetMult;
      this.onMultiplierUpdate(targetMult);
    }
  }

  /**
   * Smooth follow tracker supporting tilting, speed zoom, and hit vibrations
   */
  private updateCameraSystem(dt: number) {
    const playerZ = this.playerGroup.position.z;
    const playerX = this.playerGroup.position.x;
    const playerY = this.playerGroup.position.y;
    const time = this.clock.getElapsedTime();

    if (this.gamePhase === 'PLAYING' || this.gamePhase === 'PAUSED' || this.gamePhase === 'GAMEOVER') {
      // 1. Side lag damping (camera follows side motion with smooth delay)
      this.targetCamX = THREE.MathUtils.lerp(this.targetCamX, playerX, 8.2 * dt);

      // 2. High FOV stretch during speeds
      const targetFOV = this.isBoostActive ? 75 : 60;
      if (Math.abs(this.camera.fov - targetFOV) > 0.1) {
        this.camera.fov = THREE.MathUtils.lerp(this.camera.fov, targetFOV, 5 * dt);
        this.camera.updateProjectionMatrix();
      }

      // 3. Position and dynamic offset calculations (Cinematic Zoom out during Boost and Sweeping)
      const targetCamZOffset = this.isBoostActive ? 12.0 : 8.5;
      const targetCamYOffset = this.isBoostActive ? 5.4 : 4.2;

      this.currentCamOffsetZ = THREE.MathUtils.lerp(this.currentCamOffsetZ, targetCamZOffset, 4 * dt);
      this.currentCamOffsetY = THREE.MathUtils.lerp(this.currentCamOffsetY, targetCamYOffset, 4 * dt);

      // Elegant orbital horizontal sweep during active boost
      const dynamicCamXOffset = this.isBoostActive ? Math.sin(time * 1.5) * 1.5 : 0;

      const camZ = playerZ + this.currentCamOffsetZ;
      const camY = playerY + this.currentCamOffsetY;
      const camX = this.targetCamX + dynamicCamXOffset;
      
      this.camera.position.set(camX, camY, camZ);

      // Create stable target look-ahead focus
      const lookPercent = this.isBoostActive ? -14 : -7;
      this.reusableLookTarget.set(playerX * 0.8, playerY + 0.8, playerZ + lookPercent);

      // 4. SCREEN SHAKE SHUDDERS
      if (this.cameraShakeIntensity > 0.01) {
        const shakeX = (Math.random() - 0.5) * this.cameraShakeIntensity;
        const shakeY = (Math.random() - 0.5) * this.cameraShakeIntensity;
        this.camera.position.x += shakeX;
        this.camera.position.y += shakeY;
        
        this.cameraShakeIntensity = THREE.MathUtils.lerp(this.cameraShakeIntensity, 0, 8 * dt);
      }

      this.camera.lookAt(this.reusableLookTarget);

      // 5. Cinematic Roll/Tilt after orientation alignment
      if (this.isBoostActive) {
        // Roll slightly to match the sweeping motion
        const rollAmount = Math.cos(time * 1.5) * 0.04; // ~2.3 degrees max roll
        this.camera.rotation.z += rollAmount;
      }
    }
  }

  /**
   * Keyboard controls
   */
  private handleKeyDown = (e: KeyboardEvent) => {
    if (this.gamePhase !== 'PLAYING') return;

    if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
      // Lane switch Left
      if (this.playerLane > -1) {
        this.playerLane = (this.playerLane - 1) as Lane;
        audio.playSlide(); // whoosh switch lane sound
      }
    } 
    else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
      // Lane switch Right
      if (this.playerLane < 1) {
        this.playerLane = (this.playerLane + 1) as Lane;
        audio.playSlide();
      }
    } 
    else if ((e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') && !this.isJumping && !this.isSliding) {
      // Jump leap
      this.isJumping = true;
      this.jumpTimer = 0;
      audio.playJump();
    } 
    else if ((e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') && !this.isJumping && !this.isSliding) {
      // Slide crouch
      this.isSliding = true;
      this.slideTimer = 0;
      audio.playSlide();
    }
  };

  // CONTROL INTERFACES CALLED FROM REACT

  public setGamePhase(phase: GamePhase) {
    this.gamePhase = phase;
    this.onGamePhaseChange(phase);

    if (phase === 'PLAYING') {
      this.isCrashed = false;
      this.deactivateAllPowerUps();
      
      // Clear out previous segments, obstacles, coins, and powerups from the scene
      if (this.segments) {
        for (const seg of this.segments) {
          this.scene.remove(seg);
        }
      }
      this.segments = [];
      this.activeObstacles = [];
      this.obstacleMeshes = [];
      this.activeCoins = [];
      this.coinsMeshes = [];
      this.activePowerUps = [];
      this.powerUpMeshes = [];
      this.torchLights = [];

      // Re-initialize starting lanes/track starting from Z = 0
      this.generateInitialSegments();

      // Reset athlete position to center
      this.playerGroup.position.set(0, 0, 0);
      this.playerGroup.rotation.set(0, 0, 0);
      this.playerGroup.visible = true;
      this.playerLane = 0;
      this.targetLaneX = 0;
      this.runSpeed = 22.0;
      this.coinCount = 0;
      this.runDistance = 0;
      this.stats.score = 0;
      this.stats.coins = 0;
      this.lives = 3;
      this.isInvulnerable = false;
      this.invulnerableTimer = 0;
      this.onLivesUpdate(3);
      
      // Clear visible collection stats
      this.onScoreUpdate(0);
      this.onCoinsUpdate(0);
      this.onMultiplierUpdate(1);

      audio.startMusic();
    } else if (phase === 'START') {
      this.isCrashed = false;
      this.deactivateAllPowerUps();
      this.playerGroup.position.set(0, 0, 0);
      this.playerGroup.rotation.set(0, 0, 0);
      audio.stopMusic();
    } else if (phase === 'PAUSED') {
      audio.stopMusic();
    }
  }

  public resumeGame() {
    this.setGamePhase('PLAYING');
  }

  public pauseGame() {
    this.setGamePhase('PAUSED');
  }

  public triggerDirectCrashDebug() {
    this.triggerCrash();
  }

  private getSkinColors(skin: CharacterSkin) {
    switch (skin) {
      case 'GREEN':
        return {
          shirt: 0x2e7d32, // Deep forest green
          pants: 0x374151, // Charcoal/slate grey
          hat: 0x1b5e20    // Darker mossy green hat
        };
      case 'BLUE':
        return {
          shirt: 0x1565c0, // Blue adventure outfit
          pants: 0x263238, // Blue-grey pants
          hat: 0x0d47a1    // Navy hat
        };
      case 'TAN':
      default:
        return {
          shirt: 0xd9b98e, // Khaki beige
          pants: 0x4a3621, // Darker brown pants
          hat: 0x42250d    // Dark velvet brown fedora
        };
    }
  }

  public setSkin(skin: CharacterSkin) {
    localStorage.setItem('temple_runner_skin', skin);
    const colors = this.getSkinColors(skin);
    
    if (this.shirtMaterial) {
      this.shirtMaterial.color.setHex(colors.shirt);
    }
    if (this.pantsMaterial) {
      this.pantsMaterial.color.setHex(colors.pants);
    }
    if (this.hatMaterial) {
      this.hatMaterial.color.setHex(colors.hat);
    }
  }

  private syncRadarData() {
    if (!this.onRadarSync || this.gamePhase !== 'PLAYING') return;

    this.radarFrameCounter++;
    const playerZ = this.playerGroup.position.z;

    const radarObstacles: { lane: Lane; distance: number; type: ObstacleType }[] = [];
    const radarPowerups: { lane: Lane; distance: number; type: PowerUpType }[] = [];
    const radarCoins: { lane: Lane; distance: number }[] = [];

    // 1. Gather Obstacles
    for (const obs of this.activeObstacles) {
      const distance = playerZ - obs.z;
      // Filter for obstacles ahead of player, up to 120 meters
      if (distance >= -5 && distance <= 120) {
        // Check if the obstacle mesh is actually visible in its segment
        const segmentZOffset = Math.floor((obs.z + this.segmentLength/2) / this.segmentLength) * this.segmentLength;
        const segmentMesh = this.segments.find(s => Math.abs(s.position.z - segmentZOffset) < 1.0);
        let isVisible = true;
        if (segmentMesh && segmentMesh.children[obs.meshIndex]) {
          isVisible = segmentMesh.children[obs.meshIndex].visible;
        }
        if (isVisible) {
          radarObstacles.push({
            lane: obs.lane,
            distance: Math.max(0, distance),
            type: obs.type
          });
        }
      }
    }

    // 2. Gather Powerups
    for (const pw of this.activePowerUps) {
      if (pw.collected) continue;
      const distance = playerZ - pw.z;
      if (distance >= -5 && distance <= 120) {
        radarPowerups.push({
          lane: pw.lane,
          distance: Math.max(0, distance),
          type: pw.type
        });
      }
    }

    // 3. Gather Coins
    for (const coin of this.activeCoins) {
      if (coin.collected) continue;
      const distance = playerZ - coin.z;
      if (distance >= -5 && distance <= 120) {
        radarCoins.push({
          lane: coin.lane,
          distance: Math.max(0, distance)
        });
      }
    }

    // Sort observations so the closest ones are first
    radarObstacles.sort((a, b) => a.distance - b.distance);
    radarPowerups.sort((a, b) => a.distance - b.distance);
    radarCoins.sort((a, b) => a.distance - b.distance);

    this.onRadarSync({
      obstacles: radarObstacles,
      powerups: radarPowerups,
      coins: radarCoins
    });
  }
}
export default GameEngine;
