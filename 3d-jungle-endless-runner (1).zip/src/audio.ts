/**
 * 3D Jungle Endless Runner - Web Audio procedural sound generator & music engine
 */

class AudioEngine {
  private ctx: AudioContext | null = null;
  private musicInterval: any = null;
  private isMusicPlaying = false;
  private musicVolumeNode: GainNode | null = null;
  private sfxVolumeNode: GainNode | null = null;
  private mainGainNode: GainNode | null = null;
  
  // Settings
  private musicEnabled = true;
  private sfxEnabled = true;
  private tempo = 110; // BPM
  private beatStep = 0;

  constructor() {
    // Audio Context is initialized lazily upon first user interaction
  }

  private initContext() {
    if (this.ctx) return;
    
    // Support standard and older browsers
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;

    this.ctx = new AudioContextClass();
    
    // Create master gain
    this.mainGainNode = this.ctx.createGain();
    this.mainGainNode.gain.setValueAtTime(0.8, this.ctx.currentTime);
    this.mainGainNode.connect(this.ctx.destination);

    // Create Music Gain
    this.musicVolumeNode = this.ctx.createGain();
    // Start quiet
    this.musicVolumeNode.gain.setValueAtTime(this.musicEnabled ? 0.35 : 0, this.ctx.currentTime);
    this.musicVolumeNode.connect(this.mainGainNode);

    // Create SFX Gain
    this.sfxVolumeNode = this.ctx.createGain();
    this.sfxVolumeNode.gain.setValueAtTime(this.sfxEnabled ? 0.7 : 0, this.ctx.currentTime);
    this.sfxVolumeNode.connect(this.mainGainNode);
  }

  public setMusicEnabled(enabled: boolean) {
    this.musicEnabled = enabled;
    this.initContext();
    if (this.musicVolumeNode && this.ctx) {
      const volume = enabled ? 0.35 : 0;
      this.musicVolumeNode.gain.setTargetAtTime(volume, this.ctx.currentTime, 0.1);
    }
    if (enabled && !this.isMusicPlaying) {
      this.startMusic();
    } else if (!enabled && this.isMusicPlaying) {
      this.stopMusic();
    }
  }

  public setSfxEnabled(enabled: boolean) {
    this.sfxEnabled = enabled;
    this.initContext();
    if (this.sfxVolumeNode && this.ctx) {
      const volume = enabled ? 0.7 : 0;
      this.sfxVolumeNode.gain.setTargetAtTime(volume, this.ctx.currentTime, 0.1);
    }
  }

  public toggleMusic() {
    this.setMusicEnabled(!this.musicEnabled);
    return this.musicEnabled;
  }

  public toggleSfx() {
    this.setSfxEnabled(!this.sfxEnabled);
    return this.sfxEnabled;
  }

  public isMusicOn() { return this.musicEnabled; }
  public isSfxOn() { return this.sfxEnabled; }

  /**
   * Procedural Background Music
   * Generates a driving tribal jungle rhythm and adventurer synth bass/melody
   */
  public startMusic() {
    this.initContext();
    if (!this.ctx || !this.musicEnabled || this.isMusicPlaying) return;

    // Resume AudioContext just in case browser was suspending it
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }

    this.isMusicPlaying = true;
    this.beatStep = 0;

    const stepDuration = 60 / this.tempo / 4; // 16th notes
    let nextNoteTime = this.ctx.currentTime;

    const scheduler = () => {
      while (nextNoteTime < this.ctx!.currentTime + 0.1) {
        this.playBeatStep(this.beatStep, nextNoteTime);
        nextNoteTime += stepDuration;
        this.beatStep = (this.beatStep + 1) % 16;
      }
    };

    // Low latency loop using interval
    this.musicInterval = setInterval(scheduler, 25);
  }

  public stopMusic() {
    if (this.musicInterval) {
      clearInterval(this.musicInterval);
      this.musicInterval = null;
    }
    this.isMusicPlaying = false;
  }

  private playBeatStep(step: number, time: number) {
    if (!this.ctx || !this.musicEnabled || !this.musicVolumeNode) return;

    const ctx = this.ctx;
    const vol = this.musicVolumeNode;

    // TRIBAL DRUMS (Low tom & Snare-like noise click for organic jungle feel)
    const tomBeats = [0, 4, 8, 11, 12, 14];
    if (tomBeats.includes(step)) {
      const isDownbeat = step === 0 || step === 8;
      this.triggerJungleTom(isDownbeat ? 110 : 85, isDownbeat ? 0.25 : 0.12, time, vol);
    }

    // WOODEN RATTLE / RATTLING CABASA (Organic percussion on offbeats)
    if (step % 2 === 1) {
      this.triggerWoodenCabasa(0.04, time, vol);
    }

    // SYNTH JUNGLE ADVENTURE BASSLINE
    // A driving, hypnotic bass pattern in D minor (D - F - G - A)
    const bassNotes = [
      58.27, 58.27, 0, 58.27,      // Bb1
      65.41, 65.41, 0, 65.41,      // C2
      73.42, 73.42, 73.42, 73.42,  // D2
      87.31, 87.31, 0, 97.99       // F2 ... G2
    ];
    const bassFreq = bassNotes[Math.floor(step)];
    if (bassFreq > 0 && Math.random() > 0.1) {
      this.triggerJungleBass(bassFreq, 0.15, time, vol);
    }

    // ADVENTURER TRUMPET / PAN FLUTE ARTIFACT MELODY
    // Simple cinematic phrase playing once every 16 steps
    if (step === 2) {
      // D minor pentatonic: D4 (293Hz), F4 (349Hz), G4 (392Hz), A4 (440Hz), C5 (523Hz)
      const phrase = [293.66, 349.23, 392.00, 440.00, 392.00, 349.23, 293.66, 0];
      const note = phrase[Math.floor(time / 2) % phrase.length];
      if (note > 0) {
        this.triggerFluteMelody(note, 0.6, time, vol);
      }
    } else if (step === 10) {
      const phrase2 = [392.00, 440.00, 523.25, 587.33, 523.25, 440.00, 392.00, 0];
      const note = phrase2[Math.floor(time / 2) % phrase2.length];
      if (note > 0) {
        this.triggerFluteMelody(note, 0.6, time, vol);
      }
    }
  }

  // SOUND SYNTHESIZER BUILDERS

  private triggerJungleTom(freq: number, duration: number, time: number, output: AudioNode) {
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(freq, time);
    osc.frequency.exponentialRampToValueAtTime(0.01, time + duration);

    gain.gain.setValueAtTime(0.6, time);
    gain.gain.exponentialRampToValueAtTime(0.01, time + duration);

    osc.connect(gain);
    gain.connect(output);

    osc.start(time);
    osc.stop(time + duration);
  }

  private triggerWoodenCabasa(duration: number, time: number, output: AudioNode) {
    if (!this.ctx) return;
    
    // Synthesize simple click noise
    const bufferSize = this.ctx.sampleRate * duration;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.setValueAtTime(6000, time);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.08, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + duration);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(output);

    noise.start(time);
    noise.stop(time + duration);
  }

  private triggerJungleBass(freq: number, duration: number, time: number, output: AudioNode) {
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const filter = this.ctx.createBiquadFilter();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(freq, time);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(300, time);
    filter.frequency.exponentialRampToValueAtTime(120, time + duration);

    gain.gain.setValueAtTime(0.35, time);
    gain.gain.exponentialRampToValueAtTime(0.01, time + duration);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(output);

    osc.start(time);
    osc.stop(time + duration);
  }

  private triggerFluteMelody(freq: number, duration: number, time: number, output: AudioNode) {
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator(); // vibrato / air
    const filter = this.ctx.createBiquadFilter();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(freq, time);

    // subtle vibrato
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(freq * 1.51, time); // warm harmonic

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(2200, time);
    filter.frequency.exponentialRampToValueAtTime(800, time + duration);

    gain.gain.setValueAtTime(0.18, time);
    gain.gain.setTargetAtTime(0.001, time + duration - 0.05, 0.08);

    osc.connect(filter);
    osc2.connect(filter);
    filter.connect(gain);
    gain.connect(output);

    osc.start(time);
    osc2.start(time);
    osc.stop(time + duration);
    osc2.stop(time + duration);
  }

  // SFX TRIGGERS

  /**
   * Sound of collecting a floating gold coin
   */
  public playCoin() {
    this.initContext();
    if (!this.ctx || !this.sfxEnabled || !this.sfxVolumeNode) return;

    const time = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    // Arpeggiando ping effect
    osc.frequency.setValueAtTime(987.77, time); // B5
    osc.frequency.setValueAtTime(1318.51, time + 0.07); // E6

    gain.gain.setValueAtTime(0.18, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.35);

    osc.connect(gain);
    gain.connect(this.sfxVolumeNode);

    osc.start(time);
    osc.stop(time + 0.4);
  }

  /**
   * Jumping sound effect
   */
  public playJump() {
    this.initContext();
    if (!this.ctx || !this.sfxEnabled || !this.sfxVolumeNode) return;

    const time = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const filter = this.ctx.createBiquadFilter();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(180, time);
    osc.frequency.exponentialRampToValueAtTime(540, time + 0.25);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(900, time);

    gain.gain.setValueAtTime(0.35, time);
    gain.gain.exponentialRampToValueAtTime(0.01, time + 0.3);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxVolumeNode);

    osc.start(time);
    osc.stop(time + 0.35);
  }

  /**
   * Sliding sound effect
   */
  public playSlide() {
    this.initContext();
    if (!this.ctx || !this.sfxEnabled || !this.sfxVolumeNode) return;

    const time = this.ctx.currentTime;
    const duration = 0.4;
    
    // Noise friction base
    const bufferSize = this.ctx.sampleRate * duration;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(400, time);
    filter.frequency.exponentialRampToValueAtTime(150, time + duration);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.25, time);
    gain.gain.exponentialRampToValueAtTime(0.01, time + duration);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxVolumeNode);

    noise.start(time);
    noise.stop(time + duration);
  }

  /**
   * grabbing power up sound effect
   */
  public playPowerUp() {
    this.initContext();
    if (!this.ctx || !this.sfxEnabled || !this.sfxVolumeNode) return;

    const time = this.ctx.currentTime;
    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const osc3 = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    // Celestial chime triad (C5, E5, G5 rising up to next octave)
    osc1.frequency.setValueAtTime(523.25, time);       // C5
    osc1.frequency.exponentialRampToValueAtTime(1046.50, time + 0.4);

    osc2.frequency.setValueAtTime(659.25, time + 0.08); // E5
    osc2.frequency.exponentialRampToValueAtTime(1318.51, time + 0.48);

    osc3.frequency.setValueAtTime(783.99, time + 0.16); // G5
    osc3.frequency.exponentialRampToValueAtTime(1567.98, time + 0.56);

    gain.gain.setValueAtTime(0.12, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.7);

    osc1.connect(gain);
    osc2.connect(gain);
    osc3.connect(gain);
    gain.connect(this.sfxVolumeNode);

    osc1.start(time);
    osc2.start(time + 0.08);
    osc3.start(time + 0.16);
    osc1.stop(time + 0.7);
    osc2.stop(time + 0.7);
    osc3.stop(time + 0.7);
  }

  /**
   * Magnet pulling coin sound effect (subtle high-speed swoosh trigger)
   */
  public playMagnetStatic() {
    this.initContext();
    if (!this.ctx || !this.sfxEnabled || !this.sfxVolumeNode) return;

    // play a quick electric/sparkle sound
    const time = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(1200, time);
    osc.frequency.linearRampToValueAtTime(2400, time + 0.15);

    gain.gain.setValueAtTime(0.05, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.15);

    osc.connect(gain);
    gain.connect(this.sfxVolumeNode);

    osc.start(time);
    osc.stop(time + 0.15);
  }

  /**
   * Jet speed booster sound
   */
  public playSpeedBoost() {
    this.initContext();
    if (!this.ctx || !this.sfxEnabled || !this.sfxVolumeNode) return;

    const time = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(80, time);
    osc.frequency.exponentialRampToValueAtTime(450, time + 0.6);

    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(85, time);
    osc2.frequency.exponentialRampToValueAtTime(460, time + 0.6);

    gain.gain.setValueAtTime(0.22, time);
    gain.gain.exponentialRampToValueAtTime(0.01, time + 0.8);

    osc.connect(gain);
    osc2.connect(gain);
    gain.connect(this.sfxVolumeNode);

    osc.start(time);
    osc2.start(time);
    osc.stop(time + 0.8);
    osc2.stop(time + 0.8);
  }

  /**
   * Sound of hitting an obstacle / crash
   */
  public playCrash() {
    this.initContext();
    if (!this.ctx || !this.sfxEnabled || !this.sfxVolumeNode) return;

    const time = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const noiseGain = this.ctx.createGain();
    const oscGain = this.ctx.createGain();
    const duration = 0.6;

    // Heavy thud
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(140, time);
    osc.frequency.exponentialRampToValueAtTime(10, time + duration);

    oscGain.gain.setValueAtTime(0.65, time);
    oscGain.gain.exponentialRampToValueAtTime(0.01, time + duration);

    osc.connect(oscGain);
    oscGain.connect(this.sfxVolumeNode);

    // Explosion white noise debris
    const bufferSize = this.ctx.sampleRate * duration;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(450, time);

    noiseGain.gain.setValueAtTime(0.45, time);
    noiseGain.gain.exponentialRampToValueAtTime(0.01, time + duration);

    noise.connect(filter);
    filter.connect(noiseGain);
    noiseGain.connect(this.sfxVolumeNode);

    osc.start(time);
    noise.start(time);
    osc.stop(time + duration);
    noise.stop(time + duration);
  }

  /**
   * Shield shattering chime sound
   */
  public playShieldBreak() {
    this.initContext();
    if (!this.ctx || !this.sfxEnabled || !this.sfxVolumeNode) return;

    const time = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(1600, time);
    osc.frequency.linearRampToValueAtTime(100, time + 0.4);

    osc2.type = 'sawtooth';
    osc2.frequency.setValueAtTime(1800, time);
    osc2.frequency.linearRampToValueAtTime(200, time + 0.35);

    gain.gain.setValueAtTime(0.2, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.45);

    osc.connect(gain);
    osc2.connect(gain);
    gain.connect(this.sfxVolumeNode);

    osc.start(time);
    osc2.start(time);
    osc.stop(time + 0.5);
    osc2.stop(time + 0.5);
  }

  /**
   * Hurt grunt / crash damage sound
   */
  public playHurt() {
    this.initContext();
    if (!this.ctx || !this.sfxEnabled || !this.sfxVolumeNode) return;

    const time = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(150, time);
    osc.frequency.exponentialRampToValueAtTime(60, time + 0.25);

    gain.gain.setValueAtTime(0.4, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + 0.3);

    osc.connect(gain);
    gain.connect(this.sfxVolumeNode);

    osc.start(time);
    osc.stop(time + 0.3);
  }
}

// Export singleton instance
export const audio = new AudioEngine();
export default audio;
