import { useState, useEffect } from 'react';
import { GamePhase, PlayerStats, PowerUpType, CharacterSkin } from './types';
import { GameCanvas } from './components/GameCanvas';
import { StartScreen } from './components/StartScreen';
import { GameHUD } from './components/GameHUD';
import { PauseMenu } from './components/PauseMenu';
import { GameOverScreen } from './components/GameOverScreen';

export default function App() {
  // Game Phase
  const [gamePhase, setGamePhase] = useState<GamePhase>('START');

  // Running In-game Metrics
  const [score, setScore] = useState<number>(0);
  const [coins, setCoins] = useState<number>(0);
  const [multiplier, setMultiplier] = useState<number>(1);
  const [lives, setLives] = useState<number>(3);

  // Red flash damage hit overlay state
  const [showDamageFlash, setShowDamageFlash] = useState<boolean>(false);
  const [prevLives, setPrevLives] = useState<number>(3);

  // Monitor lives to trigger screen-shake & visual damage flash on collision damage
  useEffect(() => {
    if (lives < prevLives && gamePhase === 'PLAYING') {
      setShowDamageFlash(true);
      const timer = setTimeout(() => setShowDamageFlash(false), 350);
      return () => clearTimeout(timer);
    }
    setPrevLives(lives);
  }, [lives, prevLives, gamePhase]);

  // Active Power-ups state tracking
  const [activePowerUp, setActivePowerUp] = useState<PowerUpType | null>(null);
  const [powerUpProgress, setPowerUpProgress] = useState<number>(0);

  // Unified Session Stats (persisted high scores & cumulative coins)
  const [stats, setStats] = useState<PlayerStats>({
    score: 0,
    coins: 0,
    multiplier: 1,
    highScore: parseInt(localStorage.getItem('temple_runner_high_score') || '0', 10),
    totalCoins: parseInt(localStorage.getItem('temple_runner_total_coins') || '0', 10)
  });

  // Selected Explorer outfit skin variation
  const [characterSkin, setCharacterSkin] = useState<CharacterSkin>(() => {
    return (localStorage.getItem('temple_runner_skin') || 'TAN') as CharacterSkin;
  });

  // Callbacks invoked from the internal 3D engine loop
  const handleScoreUpdate = (currentScore: number) => {
    setScore(currentScore);
  };

  const handleCoinsUpdate = (currentCoins: number) => {
    setCoins(currentCoins);
  };

  const handleMultiplierUpdate = (currentMultiplier: number) => {
    setMultiplier(currentMultiplier);
  };

  const handlePowerUpActive = (type: PowerUpType | null, progress: number) => {
    setActivePowerUp(type);
    setPowerUpProgress(progress);
  };

  const handleStatsSync = (finalStats: PlayerStats) => {
    setStats(finalStats);
  };

  const togglePause = () => {
    if (gamePhase === 'PLAYING') {
      setGamePhase('PAUSED');
    } else if (gamePhase === 'PAUSED') {
      setGamePhase('PLAYING');
    }
  };

  const handleRestart = () => {
    setGamePhase('PLAYING');
  };

  return (
    <main className="w-screen h-screen relative bg-zinc-950 overflow-hidden select-none font-sans" id="app_root_viewport">
      
      {/* 1. Underlying 3D Viewport Layer */}
      <GameCanvas
        gamePhase={gamePhase}
        characterSkin={characterSkin}
        onScoreUpdate={handleScoreUpdate}
        onCoinsUpdate={handleCoinsUpdate}
        onMultiplierUpdate={handleMultiplierUpdate}
        onGamePhaseChange={setGamePhase}
        onPowerUpActive={handlePowerUpActive}
        onStatsSync={handleStatsSync}
        onLivesUpdate={setLives}
      />

      {/* 2. MENU OVERLAYS LAYER */}

      {/* Phase A: START Lobby */}
      {gamePhase === 'START' && (
        <StartScreen
          stats={stats}
          characterSkin={characterSkin}
          onSkinChange={(skin) => {
            setCharacterSkin(skin);
            localStorage.setItem('temple_runner_skin', skin);
          }}
          onStart={() => setGamePhase('PLAYING')}
        />
      )}

      {/* Phase B: PLAYING HUD overlay */}
      {(gamePhase === 'PLAYING' || gamePhase === 'PAUSED') && (
        <GameHUD
          score={score}
          coins={coins}
          multiplier={multiplier}
          lives={lives}
          activePowerUp={activePowerUp}
          powerUpProgress={powerUpProgress}
          onPause={togglePause}
        />
      )}

      {/* Phase C: PAUSED Suspension Menu modal */}
      {gamePhase === 'PAUSED' && (
        <PauseMenu
          onResume={() => setGamePhase('PLAYING')}
          onRestart={handleRestart}
        />
      )}

      {/* Phase D: GAMEOVER Failure overview stats */}
      {gamePhase === 'GAMEOVER' && (
        <GameOverScreen
          stats={stats}
          onRestart={handleRestart}
        />
      )}

      {/* Red flash damage screen-shake boundary overlay */}
      {showDamageFlash && (
        <div className="absolute inset-0 bg-red-600/25 pointer-events-none z-50 animate-pulse border-[10px] border-red-700/50" />
      )}
    </main>
  );
}
