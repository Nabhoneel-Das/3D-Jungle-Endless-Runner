/**
 * 3D Jungle Endless Runner - Type Definitions
 */

export type GamePhase = 'START' | 'PLAYING' | 'PAUSED' | 'GAMEOVER';

export type CharacterSkin = 'TAN' | 'GREEN' | 'BLUE';

export type Lane = -1 | 0 | 1; // -1: Left, 0: Center, 1: Right

export type PowerUpType = 'MAGNET' | 'SHIELD' | 'BOOST';

export type ObstacleType = 
  | 'SPIKES'        // Ground spikes (jump over)
  | 'BARRIER_HIGH'  // Overhead temple archway or fallen branch (slide under)
  | 'BARRIER_LOW'   // Low log or stone blocking the path (jump over)
  | 'GAP'           // Broken bridge / void in the floor (jump over or switch lanes)
  | 'ROLLING_ROCK'; // Large boulder rolling towards player (dodge or jump over)

export interface PowerUpState {
  type: PowerUpType;
  duration: number;      // Maximum duration in ms
  timeRemaining: number; // Remaining duration in ms
  active: boolean;
}

export interface PlayerStats {
  score: number;       // Meters run
  coins: number;       // Coins collected in current run
  multiplier: number;  // Current score multiplier
  highScore: number;   // Session high score
  totalCoins: number;  // Cumulative coins across all runs
}

export interface GameSettings {
  musicEnabled: boolean;
  sfxEnabled: boolean;
  difficulty: 'EASY' | 'MEDIUM' | 'HARD';
}

export interface ObstacleInstance {
  id: string;
  type: ObstacleType;
  lane: Lane;
  meshIndex: number; // reference to local segment mesh
  z: number;        // absolute Z world position
}

export interface CoinInstance {
  id: string;
  lane: Lane;
  z: number;
  y: number;
  meshIndex: number;
  collected: boolean;
  animX?: number;
  animY?: number;
  animZ?: number;
}

export interface PowerUpInstance {
  id: string;
  type: PowerUpType;
  lane: Lane;
  z: number;
  meshIndex: number;
  collected: boolean;
}
