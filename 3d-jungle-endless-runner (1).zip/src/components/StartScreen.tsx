import React, { useState } from 'react';
import { GamePhase, PlayerStats, GameSettings, CharacterSkin } from '../types';
import { audio } from '../audio';
import { Play, Volume2, VolumeX, Shield, Zap, Sparkles, Award } from 'lucide-react';

interface StartScreenProps {
  stats: PlayerStats;
  characterSkin: CharacterSkin;
  onSkinChange: (skin: CharacterSkin) => void;
  onStart: () => void;
}

export const StartScreen: React.FC<StartScreenProps> = ({ stats, characterSkin, onSkinChange, onStart }) => {
  const [musicEnabled, setMusicEnabled] = useState(audio.isMusicOn());
  const [sfxEnabled, setSfxEnabled] = useState(audio.isSfxOn());

  const handleToggleMusic = () => {
    const nextVal = audio.toggleMusic();
    setMusicEnabled(nextVal);
  };

  const handleToggleSfx = () => {
    const nextVal = audio.toggleSfx();
    setSfxEnabled(nextVal);
  };

  return (
    <div className="absolute inset-0 z-20 flex flex-col items-center justify-between p-6 bg-radial from-emerald-950/45 to-zinc-950/90 font-sans pointer-events-auto">
      
      {/* Top Header Section */}
      <div className="w-full max-w-4xl flex items-center justify-between mt-2 select-none">
        {/* Title/Stat pill */}
        <div className="flex items-center gap-3 bg-zinc-900/80 border border-emerald-800/40 rounded-full px-4 py-2 text-zinc-100 shadow-lg shadow-zinc-950/40">
          <Award className="w-5 h-5 text-amber-500 animate-pulse" />
          <span className="text-sm font-semibold tracking-wider text-emerald-400">BEST SCORE</span>
          <span className="text-base font-bold text-zinc-100">{stats.highScore} m</span>
        </div>

        {/* Total lifetime coins indicator */}
        <div className="flex items-center gap-2 bg-amber-950/45 border border-amber-500/30 rounded-full px-4 py-2 text-amber-300 shadow-lg">
          <div className="w-4 h-4 rounded-full bg-amber-400 animate-spin border border-amber-100 shadow-sm shadow-amber-300" style={{ animationDuration: '3s' }} />
          <span className="text-sm font-semibold tracking-wider text-amber-400">COINS</span>
          <span className="text-base font-bold">{stats.totalCoins}</span>
        </div>
      </div>

      {/* Center Game Logo Frame */}
      <div className="flex flex-col items-center justify-center my-auto text-center gap-1">
        
        {/* Stylized Badge */}
        <div className="flex items-center gap-1.5 px-3 py-1 bg-emerald-950 border border-emerald-500/40 rounded-md text-[10px] tracking-[0.25em] font-bold text-emerald-400 uppercase mb-3 animate-pulse">
          <Sparkles className="w-3.5 h-3.5 text-amber-500" />
          Three.js 3D Runner
        </div>

        {/* Beautiful Ancient Temple styled Title */}
        <h1 className="text-6xl md:text-7xl font-extrabold tracking-wider text-zinc-100 uppercase select-none drop-shadow-[0_5px_15px_rgba(4,47,31,0.6)]">
          TEMPLE <span className="text-transparent bg-clip-text bg-gradient-to-b from-amber-400 via-amber-200 to-amber-500">ESCORT</span>
        </h1>
        
        <p className="max-w-md text-sm text-emerald-200/70 mt-2 tracking-wide font-medium leading-relaxed">
          Escape the dark ruins of the ancient jungle temple. Vault broken walls, slide under logs, and claim your golden legacy.
        </p>

        {/* Creator Credit Accent */}
        <div className="text-xs text-amber-500/80 font-semibold tracking-wider uppercase mt-1 select-none">
          Created by <span className="text-zinc-100 font-bold decoration-amber-500 underline underline-offset-4">Nabhoneel Das</span>
        </div>

        {/* CHARACTER SKIN SELECTOR */}
        <div className="flex flex-col items-center mt-6 select-none" id="character_skin_selector">
          <span className="text-[10px] uppercase tracking-[0.2em] text-emerald-400 font-bold mb-3">
            Explorer Outfit Color
          </span>
          <div className="flex flex-wrap justify-center items-center gap-3">
            {/* TAN */}
            <button
              onClick={() => onSkinChange('TAN')}
              className={`relative flex items-center gap-3 px-4 py-2 rounded-xl border transition-all duration-200 cursor-pointer ${
                characterSkin === 'TAN'
                  ? 'bg-amber-950/45 border-amber-500 text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.25)]'
                  : 'bg-zinc-900/60 border-zinc-800/80 text-zinc-400 hover:bg-zinc-800/50 hover:text-zinc-250'
              }`}
              id="skin_btn_tan"
            >
              <div className="flex -space-x-1.5 items-center">
                <div className="w-4 h-4 rounded-full bg-[#d9b98e] border border-zinc-950/40 shadow-inner" />
                <div className="w-4 h-4 rounded-full bg-[#4a3621] border border-zinc-950/40 shadow-inner" />
              </div>
              <div className="text-left">
                <p className="text-[11px] font-bold tracking-wider leading-none uppercase">Desert Tan</p>
                <p className="text-[9px] font-medium opacity-65 mt-0.5 leading-none">Classic</p>
              </div>
            </button>

            {/* GREEN */}
            <button
              onClick={() => onSkinChange('GREEN')}
              className={`relative flex items-center gap-3 px-4 py-2 rounded-xl border transition-all duration-200 cursor-pointer ${
                characterSkin === 'GREEN'
                  ? 'bg-emerald-950/45 border-emerald-500 text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.25)]'
                  : 'bg-zinc-900/60 border-zinc-800/80 text-zinc-400 hover:bg-zinc-800/50 hover:text-zinc-250'
              }`}
              id="skin_btn_green"
            >
              <div className="flex -space-x-1.5 items-center">
                <div className="w-4 h-4 rounded-full bg-[#2e7d32] border border-zinc-950/40 shadow-inner" />
                <div className="w-4 h-4 rounded-full bg-[#374151] border border-zinc-950/40 shadow-inner" />
              </div>
              <div className="text-left">
                <p className="text-[11px] font-bold tracking-wider leading-none uppercase">Jungle Green</p>
                <p className="text-[9px] font-medium opacity-65 mt-0.5 leading-none">Safari</p>
              </div>
            </button>

            {/* BLUE */}
            <button
              onClick={() => onSkinChange('BLUE')}
              className={`relative flex items-center gap-3 px-4 py-2 rounded-xl border transition-all duration-200 cursor-pointer ${
                characterSkin === 'BLUE'
                  ? 'bg-blue-950/45 border-blue-500 text-blue-300 shadow-[0_0_12px_rgba(59,130,246,0.25)]'
                  : 'bg-zinc-900/60 border-zinc-800/80 text-zinc-400 hover:bg-zinc-800/50 hover:text-zinc-250'
              }`}
              id="skin_btn_blue"
            >
              <div className="flex -space-x-1.5 items-center">
                <div className="w-4 h-4 rounded-full bg-[#1565c0] border border-zinc-950/40 shadow-inner" />
                <div className="w-4 h-4 rounded-full bg-[#263238] border border-zinc-950/40 shadow-inner" />
              </div>
              <div className="text-left">
                <p className="text-[11px] font-bold tracking-wider leading-none uppercase">Ocean Blue</p>
                <p className="text-[9px] font-medium opacity-65 mt-0.5 leading-none">Midnight</p>
              </div>
            </button>
          </div>
        </div>

        {/* Play core button */}
        <button
          onClick={onStart}
          className="group relative flex items-center justify-center gap-3 px-12 py-5 bg-gradient-to-b from-amber-400 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-zinc-950 font-black text-xl tracking-widest uppercase rounded-xl border-t border-amber-300 shadow-2xl hover:shadow-amber-400/40 transition duration-300 cursor-pointer select-none overflow-hidden scale-100 active:scale-95 mt-9"
          id="btn_start_run"
        >
          {/* subtle moving light ray */}
          <div className="absolute inset-y-0 -left-[100%] w-1/3 bg-gradient-to-r from-white/0 via-white/20 to-white/0 skew-x-12 group-hover:animate-shimmer" style={{ animationDuration: '1.5s' }} />
          <Play className="w-6 h-6 fill-zinc-910" />
          START RUN
        </button>
      </div>

      {/* Bottom Section: Controls & Instruction Guide */}
      <div className="w-full max-w-4xl flex flex-col md:flex-row items-center justify-between gap-6 border-t border-emerald-900/30 pt-6 mt-auto">
        
        {/* Controls Layout Guide */}
        <div className="flex items-center gap-6 text-zinc-400 text-xs">
          <div className="flex flex-col gap-1">
            <span className="font-bold text-emerald-400 tracking-wider">NAVIGATE</span>
            <div className="flex gap-1.5 mt-1">
              <span className="px-2 py-1 bg-zinc-900 rounded border border-zinc-700 font-bold shadow">⚡ A</span>
              <span className="px-2 py-1 bg-zinc-900 rounded border border-zinc-700 font-bold shadow">D</span>
              <span className="text-zinc-600 self-center">or</span>
              <span className="px-2.5 py-1 bg-zinc-900 rounded border border-zinc-700 font-bold shadow">◀</span>
              <span className="px-2.5 py-1 bg-zinc-900 rounded border border-zinc-700 font-bold shadow">▶</span>
            </div>
          </div>

          <div className="h-8 w-px bg-zinc-800" />

          <div className="flex flex-col gap-1">
            <span className="font-bold text-amber-400 tracking-wider">JUMP / SLIDE</span>
            <div className="flex gap-1.5 mt-1">
              <span className="px-2 py-1 bg-zinc-900 rounded border border-zinc-700 font-semibold shadow">W / ▲</span>
              <span className="px-2 py-1 bg-zinc-900 rounded border border-zinc-700 font-semibold shadow">S / ▼</span>
            </div>
          </div>
        </div>

        {/* Audio Toggles */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleToggleMusic}
            className={`flex items-center justify-center p-3.5 rounded-lg border transition duration-150 cursor-pointer ${
              musicEnabled 
                ? 'bg-emerald-950/85 border-emerald-500/40 text-emerald-400 hover:bg-emerald-900/60' 
                : 'bg-zinc-900/80 border-zinc-700/45 text-zinc-500 hover:bg-zinc-850'
            }`}
            title={musicEnabled ? 'Mute Music' : 'Unmute Music'}
            id="btn_toggle_music"
          >
            {musicEnabled ? <Volume2 className="w-5 h-5 animate-pulse" /> : <VolumeX className="w-5 h-5" />}
          </button>

          <button
            onClick={handleToggleSfx}
            className={`flex items-center justify-center p-3.5 rounded-lg border transition duration-150 cursor-pointer ${
              sfxEnabled 
                ? 'bg-emerald-950/85 border-emerald-500/40 text-emerald-400 hover:bg-emerald-900/60' 
                : 'bg-zinc-900/80 border-zinc-700/45 text-zinc-500 hover:bg-zinc-850'
            }`}
            title={sfxEnabled ? 'Mute Sound Effects' : 'Unmute Sound Effects'}
            id="btn_toggle_sfx"
          >
            {sfxEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
          </button>
        </div>
      </div>
    </div>
  );
};
