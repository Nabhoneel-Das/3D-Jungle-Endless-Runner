import React from 'react';
import { PowerUpType } from '../types';
import { Pause, Shield, Zap, Sparkles, Heart } from 'lucide-react';

interface GameHUDProps {
  score: number;
  coins: number;
  multiplier: number;
  lives: number;
  activePowerUp: PowerUpType | null;
  powerUpProgress: number; // 0 to 1
  onPause: () => void;
}

export const GameHUD: React.FC<GameHUDProps> = ({
  score,
  coins,
  multiplier,
  lives,
  activePowerUp,
  powerUpProgress,
  onPause
}) => {
  return (
    <div className="absolute inset-0 z-10 flex flex-col justify-between p-5 pointer-events-none select-none font-sans">
      
      {/* Top Indicators Bar */}
      <div className="w-full flex items-center justify-between pointer-events-auto">
        
        {/* Left grouping of Score and Lives */}
        <div className="flex items-center gap-3">
          {/* Distance scoreboard (meters run) */}
          <div className="flex flex-col bg-zinc-950/80 border border-emerald-900/30 rounded-xl px-5 py-2.5 shadow-xl shadow-zinc-950/50 min-w-[110px]">
            <span className="text-[10px] font-bold text-emerald-400 tracking-wider">DISTANCE</span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-2xl font-black tracking-normal text-zinc-50">{score}</span>
              <span className="text-xs font-semibold text-zinc-400">m</span>
            </div>
          </div>

          {/* Lives hearts */}
          <div className="flex flex-col bg-zinc-950/80 border border-red-950/40 rounded-xl px-[18px] py-2.5 shadow-xl shadow-zinc-950/50 h-[64px]" id="hud_lives_panel">
            <span className="text-[10px] font-bold text-rose-500 tracking-wider">HEALTH</span>
            <div className="flex items-center gap-1.5 mt-1">
              {[1, 2, 3].map((heartIndex) => {
                const active = heartIndex <= lives;
                return (
                  <Heart
                    key={heartIndex}
                    className={`w-4.5 h-4.5 transition-all duration-300 ${
                      active 
                        ? 'text-rose-500 fill-rose-500 animate-pulse drop-shadow-[0_0_6px_rgba(244,63,94,0.7)]' 
                        : 'text-zinc-800 fill-zinc-950 opacity-20 scale-90'
                    }`}
                  />
                );
              })}
            </div>
          </div>
        </div>

        {/* Multiplier in middle */}
        <div className="flex items-center justify-center bg-gradient-to-b from-amber-500 to-amber-700 border border-amber-400 shadow px-4 py-2 rounded-xl text-zinc-950 font-black tracking-wide text-lg">
          {multiplier}x MULTIPLIER
        </div>

        {/* Coins count and Pause button */}
        <div className="flex items-center gap-3">
          
          {/* Coins counters */}
          <div className="flex flex-col bg-zinc-950/80 border border-amber-900/30 rounded-xl px-5 py-2.5 shadow-xl shadow-zinc-950/50 min-w-[110px] text-right">
            <span className="text-[10px] font-bold text-amber-400 tracking-wider">TEMP GOLD</span>
            <div className="flex items-center justify-end gap-1.5 mt-0.5">
              <div className="w-3.5 h-3.5 rounded-full bg-amber-400 border border-amber-200" />
              <span className="text-2xl font-black tracking-normal text-zinc-50">{coins}</span>
            </div>
          </div>

          {/* Pause button */}
          <button
            onClick={onPause}
            className="flex items-center justify-center p-3.5 bg-zinc-900/90 border border-zinc-700/50 hover:bg-zinc-800 text-zinc-200 hover:text-white rounded-xl shadow-xl hover:scale-105 active:scale-95 transition pointer-events-auto cursor-pointer"
            id="btn_pause_game"
          >
            <Pause className="w-5 h-5 fill-zinc-200" />
          </button>
        </div>
      </div>

      {/* Bottom Power-Up Progress Triggers */}
      {activePowerUp && (
        <div className="w-full max-w-sm mx-auto mb-6 bg-zinc-950/90 border border-zinc-850 rounded-2xl p-4 shadow-2xl pointer-events-auto animate-fade-in">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2.5">
              {activePowerUp === 'SHIELD' ? (
                <div className="p-2 bg-sky-950 border border-sky-500/30 rounded-lg text-sky-400">
                  <Shield className="w-5 h-5 fill-sky-400/25 animate-pulse" />
                </div>
              ) : activePowerUp === 'MAGNET' ? (
                <div className="p-2 bg-rose-950 border border-rose-500/30 rounded-lg text-rose-400">
                  <Sparkles className="w-5 h-5 animate-spin" style={{ animationDuration: '4s' }} />
                </div>
              ) : (
                <div className="p-2 bg-emerald-950 border border-emerald-500/30 rounded-lg text-emerald-400">
                  <Zap className="w-5 h-5 fill-emerald-400" />
                </div>
              )}
              
              <div className="flex flex-col">
                <span className="text-[10px] font-bold text-zinc-400 tracking-wider uppercase">ACTIVE SPECIALTY</span>
                <span className="text-sm font-black tracking-wide text-zinc-100">
                  {activePowerUp === 'SHIELD' ? 'DIVINE SHIELD' : activePowerUp === 'MAGNET' ? 'GOLD MAGNET' : 'FURY VELOCITY BOOST'}
                </span>
              </div>
            </div>

            {/* Time Percentage Text */}
            <span className="text-xs font-mono font-bold text-emerald-400">{Math.ceil(powerUpProgress * 100)}%</span>
          </div>

          {/* Progress bar container */}
          <div className="w-full h-2.5 bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
            <div
              className={`h-full rounded-full transition-all duration-100 ease-out ${
                activePowerUp === 'SHIELD' 
                  ? 'bg-gradient-to-r from-sky-500 to-sky-300' 
                  : activePowerUp === 'MAGNET' 
                  ? 'bg-gradient-to-r from-rose-500 to-amber-500' 
                  : 'bg-gradient-to-r from-emerald-500 to-lime-400'
              }`}
              style={{ width: `${powerUpProgress * 100}%` }}
            />
          </div>
        </div>
      )}
    </div>
  );
};
export default GameHUD;
