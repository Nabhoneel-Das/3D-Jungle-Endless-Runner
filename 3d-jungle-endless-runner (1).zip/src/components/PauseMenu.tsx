import React, { useState } from 'react';
import { audio } from '../audio';
import { Play, RotateCcw, Volume2, VolumeX, Eye } from 'lucide-react';

interface PauseMenuProps {
  onResume: () => void;
  onRestart: () => void;
}

export const PauseMenu: React.FC<PauseMenuProps> = ({ onResume, onRestart }) => {
  const [musicEnabled, setMusicEnabled] = useState(audio.isMusicOn());
  const [sfxEnabled, setSfxEnabled] = useState(audio.isSfxOn());

  const handleToggleMusic = () => {
    const nextVal = audio.toggleMusic();
    setMusicEnabled(nextVal);
  };

  const handleToggleSfx = () => {
    const nextVal = audio.toggleSfx();
    setSfxEnabled(nextVal);
  };

  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/75 p-6 backdrop-blur-xs select-none pointer-events-auto">
      <div className="w-full max-w-sm bg-zinc-950 border border-emerald-900/50 rounded-2xl p-6 shadow-2xl shadow-zinc-950/80 animate-scale-up text-center">
        
        {/* Header Indicator */}
        <div className="text-[10px] font-bold tracking-[0.3em] text-amber-500 uppercase mb-1">
          Escaped Ruins
        </div>
        <h2 className="text-3xl font-black text-zinc-100 tracking-wider uppercase mb-6">
          RUN SUSPENDED
        </h2>

        {/* Primary Controls */}
        <div className="flex flex-col gap-3.5 mb-6">
          
          {/* Resume */}
          <button
            onClick={onResume}
            className="flex items-center justify-center gap-2.5 w-full py-4 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-zinc-50 font-black tracking-widest text-sm uppercase rounded-xl border border-emerald-500/30 shadow-lg scale-100 active:scale-95 transition cursor-pointer"
            id="btn_resume_run"
          >
            <Play className="w-4 h-4 fill-zinc-50" />
            RESUME RUN
          </button>

          {/* Restart */}
          <button
            onClick={onRestart}
            className="flex items-center justify-center gap-2 py-4 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700/50 text-zinc-200 font-bold tracking-widest text-sm uppercase rounded-xl scale-100 active:scale-95 transition cursor-pointer"
            id="btn_restart_run_pause"
          >
            <RotateCcw className="w-4 h-4 text-zinc-400" />
            RESTART MISSION
          </button>
        </div>

        {/* Audio Adjustment Panel */}
        <div className="border-t border-zinc-900/80 pt-5 mt-2 flex flex-col items-center gap-4">
          <span className="text-[10px] font-bold text-zinc-400 tracking-widest uppercase">SOUND PREFERENCES</span>
          
          <div className="flex items-center gap-4 w-full justify-center">
            {/* Music option */}
            <button
              onClick={handleToggleMusic}
              className={`flex items-center gap-2.5 px-4 py-2.5 rounded-lg border text-xs font-bold tracking-wide transition duration-150 cursor-pointer ${
                musicEnabled 
                  ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-400' 
                  : 'bg-zinc-900/60 border-zinc-805 text-zinc-500'
              }`}
            >
              {musicEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              MUSIC: {musicEnabled ? 'ON' : 'OFF'}
            </button>

            {/* Sound FX option */}
            <button
              onClick={handleToggleSfx}
              className={`flex items-center gap-2.5 px-4 py-2.5 rounded-lg border text-xs font-bold tracking-wide transition duration-150 cursor-pointer ${
                sfxEnabled 
                  ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-400' 
                  : 'bg-zinc-900/60 border-zinc-805 text-zinc-500'
              }`}
            >
              {sfxEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              SFX: {sfxEnabled ? 'ON' : 'OFF'}
            </button>
          </div>
        </div>

        <p className="text-[10px] text-zinc-500 mt-6 leading-relaxed">
          Hovering close to hazardous ground spikes or sliding timber under overhead barriers will instantly end your campaign if unprotected by shields. Stay safe!
        </p>

      </div>
    </div>
  );
};
export default PauseMenu;
