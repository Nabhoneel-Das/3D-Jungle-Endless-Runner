import React, { useEffect, useRef } from 'react';
import { GameEngine } from '../gameEngine';
import { GamePhase, PlayerStats, PowerUpType, CharacterSkin } from '../types';
import { ChevronUp, ChevronDown, ChevronLeft, ChevronRight } from 'lucide-react';

interface GameCanvasProps {
  gamePhase: GamePhase;
  characterSkin: CharacterSkin;
  onScoreUpdate: (score: number) => void;
  onCoinsUpdate: (coins: number) => void;
  onMultiplierUpdate: (mult: number) => void;
  onGamePhaseChange: (phase: GamePhase) => void;
  onPowerUpActive: (type: PowerUpType | null, progress: number) => void;
  onStatsSync: (stats: PlayerStats) => void;
  onLivesUpdate: (lives: number) => void;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  gamePhase,
  characterSkin,
  onScoreUpdate,
  onCoinsUpdate,
  onMultiplierUpdate,
  onGamePhaseChange,
  onPowerUpActive,
  onStatsSync,
  onLivesUpdate
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<GameEngine | null>(null);

  useEffect(() => {
    if (!containerRef.current || !canvasRef.current) return;

    // Build the Three.js game engine
    const engine = new GameEngine(
      containerRef.current,
      canvasRef.current,
      {
        onScoreUpdate,
        onCoinsUpdate,
        onMultiplierUpdate,
        onGamePhaseChange,
        onPowerUpActive,
        onStatsSync,
        onLivesUpdate
      }
    );

    engineRef.current = engine;
    engine.setGamePhase(gamePhase);

    return () => {
      if (engineRef.current) {
        engineRef.current.destroy();
        engineRef.current = null;
      }
    };
  }, []); // Run once on mount

  // Sync React gamephase changes back to the engine
  useEffect(() => {
    if (engineRef.current) {
      engineRef.current.setGamePhase(gamePhase);
    }
  }, [gamePhase]);

  // Sync skin selection changes back to the engine
  useEffect(() => {
    if (engineRef.current) {
      engineRef.current.setSkin(characterSkin);
    }
  }, [characterSkin]);

  // Secondary helper triggers a fake arrow keyboard key press for touch-control buttons
  const triggerSimulationKey = (key: string) => {
    window.dispatchEvent(new KeyboardEvent('keydown', { key }));
  };

  return (
    <div ref={containerRef} className="relative w-full h-full bg-zinc-950 overflow-hidden" id="viewport_container">
      
      {/* Target canvas element */}
      <canvas ref={canvasRef} className="block w-full h-full" id="rendering_canvas" />

      {/* Floating helpful overlay showing keyboard hint or responsive mobile controls */}
      {gamePhase === 'PLAYING' && (
        <div className="absolute inset-x-0 bottom-6 z-10 flex flex-col items-center gap-2 pointer-events-none select-none">
          
          {/* Transparent click helpers (helpful for testing, mobile viewports, or trackpad users!) */}
          <div className="flex gap-4 p-2 bg-black/45 border border-zinc-800/40 rounded-2xl pointer-events-auto backdrop-blur-xs md:opacity-40 hover:opacity-100 transition duration-200">
            {/* Steer Left */}
            <button
              onClick={() => triggerSimulationKey('ArrowLeft')}
              className="p-3.5 bg-zinc-900 border border-zinc-700/60 hover:bg-zinc-800 active:scale-90 text-zinc-100 rounded-xl cursor-pointer"
              title="Steer Lane Left"
              id="steer_left_overlay"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            {/* Jump Height */}
            <button
              onClick={() => triggerSimulationKey('ArrowUp')}
              className="p-3.5 bg-zinc-900 border border-zinc-700/60 hover:bg-zinc-800 active:scale-90 text-zinc-100 rounded-xl cursor-pointer"
              title="Jump Wall"
              id="jump_up_overlay"
            >
              <ChevronUp className="w-5 h-5" />
            </button>

            {/* Slide low */}
            <button
              onClick={() => triggerSimulationKey('ArrowDown')}
              className="p-3.5 bg-zinc-900 border border-zinc-700/60 hover:bg-zinc-800 active:scale-90 text-zinc-100 rounded-xl cursor-pointer"
              title="Slide Crouch"
              id="slide_down_overlay"
            >
              <ChevronDown className="w-5 h-5" />
            </button>

            {/* Steer Right */}
            <button
              onClick={() => triggerSimulationKey('ArrowRight')}
              className="p-3.5 bg-zinc-900 border border-zinc-700/60 hover:bg-zinc-800 active:scale-90 text-zinc-100 rounded-xl cursor-pointer"
              title="Steer Lane Right"
              id="steer_right_overlay"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          <span className="text-[10px] text-zinc-400/80 font-medium tracking-widest uppercase">
            Arrow controls fully active
          </span>
        </div>
      )}
    </div>
  );
};
export default GameCanvas;
