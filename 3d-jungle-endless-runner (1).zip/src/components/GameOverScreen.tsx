import React from 'react';
import { PlayerStats } from '../types';
import { RotateCcw, Award, Sparkles, TrendingUp } from 'lucide-react';

interface GameOverScreenProps {
  stats: PlayerStats;
  onRestart: () => void;
}

export const GameOverScreen: React.FC<GameOverScreenProps> = ({ stats, onRestart }) => {
  const isNewHighScore = stats.score >= stats.highScore && stats.score > 0;

  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/85 p-6 backdrop-blur-xs select-none pointer-events-auto">
      <div className="w-full max-w-md bg-zinc-950 border border-red-900/40 rounded-3xl p-7 shadow-3xl shadow-zinc-950/95 animate-scale-up text-center relative overflow-hidden">
        
        {/* Golden Sparkles for New High score */}
        {isNewHighScore && (
          <div className="absolute top-0 inset-x-0 h-1.5 bg-gradient-to-r from-amber-400 via-amber-200 to-amber-500 animate-pulse" />
        )}

        <div className="text-[11px] font-bold tracking-[0.25em] text-red-500 uppercase mb-1">
          Temple Guardian Intercepted
        </div>
        <h2 className="text-4xl font-extrabold text-zinc-100 uppercase tracking-widest mb-1.5">
          RUN COMPLETED
        </h2>
        <p className="text-xs text-zinc-500 mb-6 font-sans">Your adventure has met an abrupt cliffside conclusion.</p>
        
        {/* Creator Credit Accent */}
        <div className="text-[10px] text-amber-500/70 font-semibold tracking-wider uppercase mb-5 select-none text-center">
          Created by <span className="text-zinc-200 font-bold decoration-amber-500/80 underline underline-offset-4">Nabhoneel Das</span>
        </div>

        {/* High-Impact New record banner */}
        {isNewHighScore ? (
          <div className="flex items-center justify-center gap-2 px-5 py-3.5 bg-amber-500/15 border border-amber-500/35 rounded-2xl text-amber-300 font-extrabold text-sm tracking-widest uppercase mb-6 animate-pulse">
            <Award className="w-5 h-5 text-amber-400 fill-amber-400/25" />
            <span>NEW CATHEDRAL RECORD!</span>
            <Sparkles className="w-4 h-4 text-amber-400 animate-spin" style={{ animationDuration: '6s' }} />
          </div>
        ) : (
          <div className="h-2" />
        )}

        {/* Run Stats Cards Group */}
        <div className="grid grid-cols-2 gap-3 mb-7 text-left">
          
          {/* Distance achievement */}
          <div className="bg-zinc-900/70 border border-zinc-800/60 rounded-2xl p-4 flex flex-col justify-between">
            <span className="text-[10px] font-bold text-zinc-400 tracking-wider">DISTANCE SURGED</span>
            <div className="flex items-baseline gap-1 mt-2.5">
              <span className="text-3xl font-black text-zinc-50">{stats.score}</span>
              <span className="text-xs font-bold text-zinc-500">meters</span>
            </div>
          </div>

          {/* Coins obtained */}
          <div className="bg-zinc-900/70 border border-zinc-800/60 rounded-2xl p-4 flex flex-col justify-between">
            <span className="text-[10px] font-bold text-zinc-400 tracking-wider font-sans">COINS HARVESTED</span>
            <div className="flex items-baseline gap-1.5 mt-2.5">
              <span className="text-3xl font-black text-zinc-50 font-sans">{stats.coins}</span>
              <div className="w-3.5 h-3.5 rounded-full bg-amber-400 border border-amber-200" />
            </div>
          </div>

          {/* Combined Multipliers info */}
          <div className="col-span-2 bg-gradient-to-r from-emerald-950/40 to-teal-950/40 border border-emerald-900/30 rounded-2xl p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-emerald-900/40 border border-emerald-500/30 rounded-xl text-emerald-400">
                <TrendingUp className="w-4 h-4" />
              </div>
              <div className="flex flex-col text-left">
                <span className="text-[9px] font-extrabold text-emerald-400 tracking-wider uppercase">MULTIPLIER INFLUENCE</span>
                <span className="text-xs font-semibold text-zinc-300">Achieved pace level: <strong className="text-white">{stats.multiplier}x</strong></span>
              </div>
            </div>
            
            {/* Show Session Peak score */}
            <div className="text-right">
              <span className="text-[9px] font-bold text-zinc-400 tracking-wide uppercase">RECORD DISTANCE</span>
              <div className="text-sm font-black text-zinc-100">{stats.highScore} m</div>
            </div>
          </div>
        </div>

        {/* Retry Button */}
        <button
          onClick={onRestart}
          className="group relative flex items-center justify-center gap-2.5 w-full py-5 bg-gradient-to-r from-amber-400 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-zinc-950 font-black tracking-widest text-base uppercase rounded-2xl shadow-xl hover:shadow-amber-500/20 hover:scale-102 active:scale-97 transition duration-200 cursor-pointer overflow-hidden"
          id="btn_play_again"
        >
          <div className="absolute inset-y-0 -left-[100%] w-1/3 bg-gradient-to-r from-white/0 via-white/20 to-white/0 skew-x-12 group-hover:animate-shimmer" style={{ animationDuration: '2s' }} />
          <RotateCcw className="w-5 h-5" />
          START A NEW RUN
        </button>

      </div>
    </div>
  );
};
export default GameOverScreen;
